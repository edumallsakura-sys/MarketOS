# X Dubbing Studio v2.2 X-ONLY REAL

Project Android chỉ tập trung video X.com. Lingua Mentor APK chỉ được dùng làm mẫu kiến trúc native bridge.

## Giữ lại
- X.com URL + X widget playback
- Android MediaProjection + AudioPlaybackCapture (Android 10+)
- PCM 16 kHz mono chuyển về JavaScript qua `__x50OnAudioChunk`
- PCM -> WAV thật trong UI
- Whisper backend tùy chọn qua native HTTP POST (base64 WAV JSON)
- Import SRT/VTT timestamp thật
- ML Kit EN -> VI native
- Android TextToSpeech native

## Bỏ hoàn toàn
- 1000 từ / phrase audio
- ebook / PDF
- lesson screens
- tài nguyên học ngoại ngữ của Lingua Mentor

## Giới hạn thật
Android AudioPlaybackCapture không thể ép X/Chrome/WebView cho phép capture nếu nguồn/OS chặn. Khi audio gần như im lặng service trả `SILENT_OR_POLICY_BLOCKED`. Project không giả transcript và không tuyên bố bypass X.

Whisper on-device chưa được nhúng native trong project này. Transcript tự động cần backend tương thích JSON hoặc file SRT/VTT. Đây là chủ ý để không gắn nhãn "Whisper READY" giả.
