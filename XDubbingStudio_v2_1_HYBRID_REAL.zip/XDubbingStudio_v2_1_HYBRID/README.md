# X Dubbing Studio v2.1 HYBRID REAL

Rebuilt from the working Lingua Mentor APK architecture supplied by the user.

## What changed from v2.0
- Uses the real `assets/app.html` from the supplied working app, including IndexedDB/local persistence, API routing, bundled phrase audio, X/YouTube workspace and browser Whisper paths.
- Implements the same `window.NativeApp` + `__nativeResolve(id,payload)` contract expected by that HTML.
- Native Android TTS: `ttsSpeakAsync`, `ttsStopAsync`.
- Native ML Kit translation bridge: `translateAsync`.
- Native HTTP POST bridge: `httpPostAsync` for API calls that need to avoid WebView CORS limitations.
- Real Android 10+ MediaProjection + AudioPlaybackCapture bridge: `startSystemAudioCapture` / `stopSystemAudioCapture`.
- PCM 16 kHz mono is streamed back to the HTML through `__x50OnAudioChunk`, exactly matching the supplied app's system-audio ASR path.
- Serves the UI under `https://app.luyennghe.local/` and maps bundled audio assets to that same origin.

## Important platform limitation
Android AudioPlaybackCapture only captures apps/audio usages that permit playback capture. If X or its player blocks capture, the app reports `SILENT_OR_POLICY_BLOCKED`; it does not fake audio or transcript.

## Build
GitHub Actions workflow is included. Debug APK task: `assembleDebug`.
