package com.quansuhuyentri.xdubbing;

import java.io.*;

public final class WavUtil {
    private WavUtil() {}

    public static File pcm16ToWav(File pcm, int sampleRate, int channels) throws IOException {
        File wav = new File(pcm.getParentFile(), pcm.getName().replace(".pcm", ".wav"));
        long dataLen = pcm.length();
        long byteRate = (long) sampleRate * channels * 2;
        try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(wav)));
             InputStream in = new BufferedInputStream(new FileInputStream(pcm))) {
            writeAscii(out, "RIFF"); writeLE32(out, 36 + dataLen); writeAscii(out, "WAVE");
            writeAscii(out, "fmt "); writeLE32(out, 16); writeLE16(out, 1); writeLE16(out, channels);
            writeLE32(out, sampleRate); writeLE32(out, byteRate); writeLE16(out, channels * 2); writeLE16(out, 16);
            writeAscii(out, "data"); writeLE32(out, dataLen);
            byte[] b = new byte[32768];
            int n;
            while ((n = in.read(b)) > 0) out.write(b, 0, n);
        }
        return wav;
    }

    private static void writeAscii(DataOutputStream o, String s) throws IOException { o.writeBytes(s); }
    private static void writeLE16(DataOutputStream o, long v) throws IOException { o.writeByte((int) v); o.writeByte((int) (v >> 8)); }
    private static void writeLE32(DataOutputStream o, long v) throws IOException {
        o.writeByte((int) v); o.writeByte((int) (v >> 8)); o.writeByte((int) (v >> 16)); o.writeByte((int) (v >> 24));
    }
}
