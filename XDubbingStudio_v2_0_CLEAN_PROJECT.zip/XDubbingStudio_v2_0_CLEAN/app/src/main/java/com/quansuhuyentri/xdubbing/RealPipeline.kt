package com.quansuhuyentri.xdubbing

import android.content.Context
import dev.ffmpegkit.whisper.Whisper
import dev.ffmpegkit.whisper.WhisperConfig
import dev.ffmpegkit.whisper.WhisperModel
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

object RealPipeline {
    private const val MODEL_URL = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin?download=true"
    private const val MODEL_NAME = "ggml-base.bin"
    private const val MIN_MODEL_BYTES = 100_000_000L

    @Volatile private var model: WhisperModel? = null

    interface Callback {
        fun emit(type: String, status: String, detail: JSONObject)
    }

    @JvmStatic
    fun transcribeChunk(context: Context, wav: File, baseSec: Double, chunkIndex: Int, cb: Callback) = runBlocking {
        try {
            val modelFile = ensureModel(context, cb)
            var loaded = model
            if (loaded == null) {
                loaded = Whisper.loadModel(context, modelFile.absolutePath)
                model = loaded
                cb.emit(
                    "whisper-model",
                    "READY",
                    JSONObject()
                        .put("path", modelFile.absolutePath)
                        .put("bytes", modelFile.length())
                        .put("system", Whisper.getSystemInfo())
                )
            }

            cb.emit(
                "whisper-chunk",
                "PROCESSING",
                JSONObject().put("chunkIndex", chunkIndex).put("baseSec", baseSec).put("wav", wav.absolutePath)
            )

            val result = Whisper.transcribe(loaded, wav.absolutePath, WhisperConfig(language = "auto"))
            val segments = JSONArray()
            result.segments.forEach { segment ->
                val original = segment.text.trim()
                if (original.isNotEmpty()) {
                    val vi = try {
                        MlKitTranslator.translateToVietnameseBlocking(original)
                    } catch (_: Exception) {
                        original
                    }
                    segments.put(
                        JSONObject()
                            .put("startMs", (baseSec * 1000.0).toLong() + segment.startMs)
                            .put("endMs", (baseSec * 1000.0).toLong() + segment.endMs)
                            .put("text", original)
                            .put("textVi", vi)
                    )
                }
            }
            cb.emit(
                "transcript-chunk",
                "DONE",
                JSONObject()
                    .put("chunkIndex", chunkIndex)
                    .put("baseSec", baseSec)
                    .put("text", result.text)
                    .put("segments", segments)
            )
        } catch (t: Throwable) {
            cb.emit(
                "pipeline-error",
                "ERROR",
                JSONObject().put("chunkIndex", chunkIndex).put("message", t.toString())
            )
        }
    }

    @JvmStatic
    fun releaseModel() {
        model?.let { Whisper.releaseModel(it) }
        model = null
    }

    private fun ensureModel(context: Context, cb: Callback): File {
        val dir = context.getExternalFilesDir("models") ?: File(context.filesDir, "models")
        if (!dir.exists() && !dir.mkdirs()) throw IllegalStateException("Cannot create model directory")
        val target = File(dir, MODEL_NAME)
        if (target.exists() && target.length() >= MIN_MODEL_BYTES) return target

        val part = File(dir, "$MODEL_NAME.part")
        cb.emit("whisper-model", "DOWNLOADING", JSONObject().put("url", MODEL_URL).put("path", target.absolutePath))
        val connection = URL(MODEL_URL).openConnection() as HttpURLConnection
        try {
            connection.instanceFollowRedirects = true
            connection.connectTimeout = 20_000
            connection.readTimeout = 60_000
            connection.setRequestProperty("User-Agent", "X-Dubbing-Studio/2.0")
            connection.connect()
            if (connection.responseCode !in 200..299) throw IllegalStateException("Model HTTP ${connection.responseCode}")

            val total = connection.contentLengthLong
            connection.inputStream.use { input ->
                FileOutputStream(part).use { output ->
                    val buffer = ByteArray(1024 * 1024)
                    var done = 0L
                    var lastPercent = -1
                    while (true) {
                        val read = input.read(buffer)
                        if (read <= 0) break
                        output.write(buffer, 0, read)
                        done += read
                        val percent = if (total > 0) ((done * 100) / total).toInt() else -1
                        if (percent >= 0 && percent != lastPercent && percent % 5 == 0) {
                            lastPercent = percent
                            cb.emit(
                                "whisper-model",
                                "DOWNLOADING",
                                JSONObject().put("percent", percent).put("bytes", done).put("total", total)
                            )
                        }
                    }
                }
            }
        } finally {
            connection.disconnect()
        }

        if (part.length() < MIN_MODEL_BYTES) throw IllegalStateException("Downloaded Whisper model is too small: ${part.length()}")
        if (target.exists() && !target.delete()) throw IllegalStateException("Cannot replace old Whisper model")
        if (!part.renameTo(target)) throw IllegalStateException("Cannot finalize Whisper model")
        return target
    }
}
