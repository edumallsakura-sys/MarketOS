package com.quansuhuyentri.xdubbing;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import org.json.JSONObject;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class PlaybackCaptureService extends Service {
    public static final String ACTION_START = "com.quansuhuyentri.xdubbing.START_CAPTURE";
    public static final String ACTION_STOP = "com.quansuhuyentri.xdubbing.STOP_CAPTURE";
    public static final String EXTRA_RESULT_CODE = "resultCode";
    public static final String EXTRA_RESULT_DATA = "resultData";
    public static final String EXTRA_SOURCE_JSON = "sourceJson";

    private static final int NOTIFICATION_ID = 1718;
    private static final String CHANNEL_ID = "xds_capture";
    private static final int SAMPLE_RATE = 16000;
    private static final int CHANNELS = 1;
    private static final int BYTES_PER_SAMPLE = 2;
    private static final int CHUNK_SECONDS = 12;

    private final AtomicBoolean running = new AtomicBoolean(false);
    private final ExecutorService transcribeExecutor = Executors.newSingleThreadExecutor();
    private AudioRecord audioRecord;
    private MediaProjection projection;
    private MediaProjection.Callback projectionCallback;
    private Thread captureThread;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        if (ACTION_STOP.equals(intent.getAction())) {
            stopCapture();
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(intent.getAction()) || running.get()) return START_NOT_STICKY;

        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("X Dubbing Studio")
                .setContentText("Capturing permitted playback audio")
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }

        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        Intent resultData;
        if (Build.VERSION.SDK_INT >= 33) {
            resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
        } else {
            resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA);
        }
        if (resultData == null) {
            emit("capture-error", "MISSING_PROJECTION_DATA", null);
            stopSelf();
            return START_NOT_STICKY;
        }

        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = manager.getMediaProjection(resultCode, resultData);
        if (projection == null) {
            emit("capture-error", "GET_MEDIA_PROJECTION_FAILED", null);
            stopSelf();
            return START_NOT_STICKY;
        }
        projectionCallback = new MediaProjection.Callback() {
            @Override public void onStop() { stopCapture(); }
        };
        projection.registerCallback(projectionCallback, new Handler(Looper.getMainLooper()));

        try {
            startAudioRecord(intent.getStringExtra(EXTRA_SOURCE_JSON));
        } catch (Exception e) {
            emit("capture-error", e.toString(), null);
            stopCapture();
        }
        return START_NOT_STICKY;
    }

    private void startAudioRecord(String sourceJson) throws Exception {
        AudioPlaybackCaptureConfiguration captureConfig =
                new AudioPlaybackCaptureConfiguration.Builder(projection)
                        .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                        .addMatchingUsage(AudioAttributes.USAGE_GAME)
                        .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                        .build();

        AudioFormat format = new AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build();
        int minBuffer = AudioRecord.getMinBufferSize(
                SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if (minBuffer <= 0) throw new IllegalStateException("AudioRecord buffer unsupported: " + minBuffer);
        int bufferBytes = Math.max(minBuffer * 4, SAMPLE_RATE * BYTES_PER_SAMPLE / 2);

        audioRecord = new AudioRecord.Builder()
                .setAudioFormat(format)
                .setBufferSizeInBytes(bufferBytes)
                .setAudioPlaybackCaptureConfig(captureConfig)
                .build();
        if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED) {
            throw new IllegalStateException("AudioRecord not initialized");
        }

        audioRecord.startRecording();
        running.set(true);
        emit("capture-started", "PCM_16K_MONO", sourceJson);
        captureThread = new Thread(() -> captureLoop(bufferBytes), "xds-playback-capture");
        captureThread.start();
    }

    private void captureLoop(int bufferBytes) {
        byte[] buffer = new byte[bufferBytes];
        long chunkTargetBytes = (long) SAMPLE_RATE * CHANNELS * BYTES_PER_SAMPLE * CHUNK_SECONDS;
        int chunkIndex = 0;
        try {
            while (running.get()) {
                File dir = new File(getFilesDir(), "pcm");
                if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Cannot create PCM directory");
                File chunk = new File(dir, String.format("chunk_%05d_%d.pcm", chunkIndex, System.currentTimeMillis()));
                long written = 0;
                long nonZero = 0;

                try (BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(chunk))) {
                    while (running.get() && written < chunkTargetBytes) {
                        int wanted = (int) Math.min(buffer.length, chunkTargetBytes - written);
                        int read = audioRecord.read(buffer, 0, wanted, AudioRecord.READ_BLOCKING);
                        if (read < 0) throw new IllegalStateException("AudioRecord read error " + read);
                        if (read == 0) continue;
                        out.write(buffer, 0, read);
                        written += read;
                        for (int i = 0; i + 1 < read; i += 2) {
                            if (buffer[i] != 0 || buffer[i + 1] != 0) nonZero += 2;
                        }
                    }
                }

                if (written == 0) {
                    chunk.delete();
                    continue;
                }

                double signalRatio = (double) nonZero / (double) written;
                JSONObject detail = new JSONObject();
                detail.put("chunkIndex", chunkIndex);
                detail.put("baseSec", chunkIndex * CHUNK_SECONDS);
                detail.put("durationSec", (double) written / (SAMPLE_RATE * CHANNELS * BYTES_PER_SAMPLE));
                detail.put("bytes", written);
                detail.put("sampleRate", SAMPLE_RATE);
                detail.put("channels", CHANNELS);
                detail.put("encoding", "PCM_S16LE");
                detail.put("signalRatio", signalRatio);
                detail.put("path", chunk.getAbsolutePath());
                emit("pcm-chunk", signalRatio < 0.001 ? "SILENT_OR_POLICY_BLOCKED" : "CAPTURED", detail.toString());

                if (signalRatio >= 0.001) {
                    final int currentIndex = chunkIndex;
                    final double baseSec = currentIndex * CHUNK_SECONDS;
                    final File currentChunk = chunk;
                    transcribeExecutor.submit(() -> transcribe(currentChunk, baseSec, currentIndex));
                }
                chunkIndex++;
            }
        } catch (Exception e) {
            emit("capture-error", e.toString(), null);
        } finally {
            cleanup();
            stopSelf();
        }
    }

    private void transcribe(File pcm, double baseSec, int chunkIndex) {
        try {
            File wav = WavUtil.pcm16ToWav(pcm, SAMPLE_RATE, CHANNELS);
            RealPipeline.transcribeChunk(getApplicationContext(), wav, baseSec, chunkIndex,
                    (type, status, detail) -> {
                        JSONObject event = new JSONObject();
                        try {
                            event.put("type", type);
                            event.put("status", status);
                            event.put("ts", System.currentTimeMillis());
                            event.put("detail", detail);
                        } catch (Exception ignored) {}
                        MainActivity.emitFromService(event);
                    });
        } catch (Exception e) {
            emit("pipeline-error", e.toString(), null);
        }
    }

    private void stopCapture() {
        running.set(false);
        if (audioRecord != null) {
            try { audioRecord.stop(); } catch (Exception ignored) {}
        }
        if (captureThread == null) {
            cleanup();
            stopSelf();
        }
    }

    private void cleanup() {
        if (audioRecord != null) {
            try { audioRecord.release(); } catch (Exception ignored) {}
            audioRecord = null;
        }
        if (projection != null) {
            if (projectionCallback != null) {
                try { projection.unregisterCallback(projectionCallback); } catch (Exception ignored) {}
            }
            try { projection.stop(); } catch (Exception ignored) {}
            projection = null;
        }
        stopForeground(STOP_FOREGROUND_REMOVE);
        running.set(false);
    }

    private void emit(String type, String status, String detail) {
        JSONObject object = new JSONObject();
        try {
            object.put("type", type);
            object.put("status", status);
            object.put("ts", System.currentTimeMillis());
            if (detail != null) {
                try { object.put("detail", new JSONObject(detail)); }
                catch (Exception ignored) { object.put("detail", detail); }
            }
        } catch (Exception ignored) {}
        MainActivity.emitFromService(object);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Playback capture", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    @Override public void onDestroy() {
        stopCapture();
        transcribeExecutor.shutdownNow();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
