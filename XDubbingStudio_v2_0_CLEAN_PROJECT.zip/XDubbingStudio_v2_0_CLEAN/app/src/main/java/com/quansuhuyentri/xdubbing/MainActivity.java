package com.quansuhuyentri.xdubbing;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.File;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_RECORD_AUDIO = 1001;
    private static final int REQ_MEDIA_PROJECTION = 1002;
    private static WeakReference<MainActivity> liveActivity = new WeakReference<>(null);

    private WebView webView;
    private MediaProjectionManager projectionManager;
    private TextToSpeech tts;
    private boolean ttsReady;
    private String pendingCapturePayload = "{}";

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        liveActivity = new WeakReference<>(this);
        projectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        initTts();
        initWebView();
    }

    private void initWebView() {
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSafeBrowsingEnabled(true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                return !("file".equalsIgnoreCase(scheme) || "about".equalsIgnoreCase(scheme));
            }
        });
        webView.addJavascriptInterface(new NativeBridge(), "XDubbingNative");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void initTts() {
        tts = new TextToSpeech(this, status -> {
            ttsReady = status == TextToSpeech.SUCCESS;
            if (ttsReady) {
                int result = tts.setLanguage(new Locale("vi", "VN"));
                emit(event("tts-engine", "ready", result >= TextToSpeech.LANG_AVAILABLE ? "vi-VN" : "default"));
            } else {
                emit(event("tts-engine", "error", "TextToSpeech init failed"));
            }
        });
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String utteranceId) { emit(event("tts", "playing", utteranceId)); }
            @Override public void onDone(String utteranceId) {
                File out = new File(getCacheDir(), "tts/" + utteranceId + ".wav");
                runOnUiThread(() -> playFile(out));
            }
            @Override public void onError(String utteranceId) { emit(event("tts", "error", utteranceId)); }
        });
    }

    private void requestCapture(String payload) {
        pendingCapturePayload = payload == null ? "{}" : payload;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_RECORD_AUDIO);
            return;
        }
        launchProjectionConsent();
    }

    private void launchProjectionConsent() {
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_MEDIA_PROJECTION);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_RECORD_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                launchProjectionConsent();
            } else {
                emit(event("capture-error", "permission", "RECORD_AUDIO denied"));
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_MEDIA_PROJECTION) return;
        if (resultCode != RESULT_OK || data == null) {
            emit(event("capture-error", "projection", "MediaProjection denied"));
            return;
        }
        Intent service = new Intent(this, PlaybackCaptureService.class);
        service.setAction(PlaybackCaptureService.ACTION_START);
        service.putExtra(PlaybackCaptureService.EXTRA_RESULT_CODE, resultCode);
        service.putExtra(PlaybackCaptureService.EXTRA_RESULT_DATA, data);
        service.putExtra(PlaybackCaptureService.EXTRA_SOURCE_JSON, pendingCapturePayload);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
    }

    private void stopCapture() {
        Intent service = new Intent(this, PlaybackCaptureService.class);
        service.setAction(PlaybackCaptureService.ACTION_STOP);
        startService(service);
    }

    private void replayTts(String payload) {
        try {
            JSONObject object = new JSONObject(payload == null ? "{}" : payload);
            String cueId = object.optString("id", "cue");
            String text = object.optString("text", "").trim();
            if (text.isEmpty()) throw new IllegalArgumentException("Missing TTS text");

            File dir = new File(getCacheDir(), "tts");
            if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Cannot create TTS cache");
            String key = sha256(text);
            File out = new File(dir, key + ".wav");
            if (out.exists() && out.length() > 44) {
                playFile(out);
                emit(event("tts-cache", "hit", cueId));
                return;
            }
            if (!ttsReady) throw new IllegalStateException("Android TTS engine not ready");
            int result = tts.synthesizeToFile(text, new Bundle(), out, key);
            if (result != TextToSpeech.SUCCESS) throw new IllegalStateException("synthesizeToFile rejected");
            emit(event("tts-cache", "miss", cueId));
        } catch (Exception e) {
            emit(event("tts", "error", e.toString()));
        }
    }

    private void playFile(File file) {
        if (file == null || !file.exists()) return;
        try {
            MediaPlayer player = new MediaPlayer();
            player.setDataSource(file.getAbsolutePath());
            player.setOnCompletionListener(mp -> {
                mp.release();
                emit(event("tts", "done", file.getName()));
            });
            player.setOnErrorListener((mp, what, extra) -> {
                mp.release();
                emit(event("tts", "error", "MediaPlayer " + what + "/" + extra));
                return true;
            });
            player.prepare();
            player.start();
        } catch (Exception e) {
            emit(event("tts", "error", e.toString()));
        }
    }

    private static String sha256(String text) throws Exception {
        byte[] hash = MessageDigest.getInstance("SHA-256").digest(text.getBytes(StandardCharsets.UTF_8));
        StringBuilder builder = new StringBuilder();
        for (byte value : hash) builder.append(String.format("%02x", value));
        return builder.toString();
    }

    private static JSONObject event(String type, String status, String message) {
        JSONObject object = new JSONObject();
        try {
            object.put("type", type);
            object.put("status", status);
            object.put("message", message);
            object.put("ts", System.currentTimeMillis());
        } catch (Exception ignored) {}
        return object;
    }

    static void emitFromService(JSONObject event) {
        MainActivity activity = liveActivity.get();
        if (activity != null) activity.emit(event);
    }

    private void emit(JSONObject event) {
        if (webView == null || event == null) return;
        String quoted = JSONObject.quote(event.toString());
        runOnUiThread(() -> webView.evaluateJavascript(
                "window.XDSNativeEvent && window.XDSNativeEvent(" + quoted + ");", null));
    }

    @Override
    protected void onDestroy() {
        liveActivity.clear();
        RealPipeline.releaseModel();
        if (webView != null) webView.destroy();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    public final class NativeBridge {
        @JavascriptInterface
        public String parseSource(String json) {
            try {
                JSONObject input = new JSONObject(json == null ? "{}" : json);
                String url = input.optString("url", "");
                boolean isXStatus = url.matches("^https://(www\\.)?(x\\.com|twitter\\.com)/[^/]+/status/\\d+(?:[/?#].*)?$");
                JSONObject out = new JSONObject();
                out.put("ok", isXStatus);
                out.put("url", url);
                out.put("author", input.optString("author"));
                out.put("tweetId", input.optString("tweetId"));
                if (!isXStatus) out.put("error", "INVALID_X_STATUS_URL");
                return out.toString();
            } catch (Exception e) {
                return "{\"ok\":false,\"error\":" + JSONObject.quote(e.toString()) + "}";
            }
        }

        @JavascriptInterface
        public String startCapture(String json) {
            runOnUiThread(() -> requestCapture(json));
            return "{\"accepted\":true,\"state\":\"AWAITING_MEDIA_PROJECTION_CONSENT\"}";
        }

        @JavascriptInterface
        public String stopCapture(String json) {
            runOnUiThread(MainActivity.this::stopCapture);
            return "{\"accepted\":true,\"state\":\"STOPPING\"}";
        }

        @JavascriptInterface
        public String replayTts(String json) {
            runOnUiThread(() -> MainActivity.this.replayTts(json));
            return "{\"accepted\":true}";
        }
    }
}
