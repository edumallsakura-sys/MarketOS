package com.quansuhuyentri.xdubbing;

import com.google.android.gms.tasks.Task;
import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.languageid.LanguageIdentification;
import com.google.mlkit.nl.languageid.LanguageIdentifier;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReference;

public final class MlKitTranslator {
    private MlKitTranslator() {}

    public static String translateToVietnameseBlocking(String text) throws Exception {
        if (text == null || text.trim().isEmpty()) return "";
        String sourceTag = identifyBlocking(text);
        String source = TranslateLanguage.fromLanguageTag(sourceTag);
        if (source == null || "und".equals(sourceTag)) source = TranslateLanguage.ENGLISH;
        if (TranslateLanguage.VIETNAMESE.equals(source)) return text;

        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(source)
                .setTargetLanguage(TranslateLanguage.VIETNAMESE)
                .build();
        Translator translator = Translation.getClient(options);
        try {
            awaitVoid(translator.downloadModelIfNeeded(new DownloadConditions.Builder().build()), 120);
            return awaitString(translator.translate(text), 60);
        } finally {
            translator.close();
        }
    }

    private static String identifyBlocking(String text) throws Exception {
        LanguageIdentifier id = LanguageIdentification.getClient();
        try {
            return awaitString(id.identifyLanguage(text), 30);
        } finally {
            id.close();
        }
    }

    private static String awaitString(Task<String> task, int seconds) throws Exception {
        CountDownLatch latch = new CountDownLatch(1);
        AtomicReference<String> value = new AtomicReference<>();
        AtomicReference<Exception> error = new AtomicReference<>();
        task.addOnSuccessListener(v -> { value.set(v); latch.countDown(); })
                .addOnFailureListener(e -> { error.set(e); latch.countDown(); });
        if (!latch.await(seconds, TimeUnit.SECONDS)) throw new TimeoutException("ML Kit timeout");
        if (error.get() != null) throw error.get();
        return value.get();
    }

    private static void awaitVoid(Task<Void> task, int seconds) throws Exception {
        CountDownLatch latch = new CountDownLatch(1);
        AtomicReference<Exception> error = new AtomicReference<>();
        task.addOnSuccessListener(v -> latch.countDown())
                .addOnFailureListener(e -> { error.set(e); latch.countDown(); });
        if (!latch.await(seconds, TimeUnit.SECONDS)) throw new TimeoutException("ML Kit model download timeout");
        if (error.get() != null) throw error.get();
    }
}
