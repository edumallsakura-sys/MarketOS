# No shrinking in v2.0 debug/release baseline.
