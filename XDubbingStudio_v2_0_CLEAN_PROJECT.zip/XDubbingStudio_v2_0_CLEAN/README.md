# X Dubbing Studio Android v2.0 CLEAN

Clean Android baseline rebuilt from scratch.

## Real pipeline

Trusted local WebView UI -> Android JavaScript bridge -> MediaProjection consent -> AudioPlaybackCapture -> PCM 16 kHz mono chunks -> WAV -> on-device whisper-android -> timestamped segments -> ML Kit translation to Vietnamese -> Android TTS cache/replay.

## Important Android limitation

AudioPlaybackCapture cannot override another app's capture policy. If the source app/player disallows playback capture, this app reports `SILENT_OR_POLICY_BLOCKED`; it does not fake success or bypass Android policy.

## Build

GitHub Actions builds an installable debug APK with JDK 17 / Gradle 8.9. AndroidX and JVM targets are configured in source, not patched in CI.
