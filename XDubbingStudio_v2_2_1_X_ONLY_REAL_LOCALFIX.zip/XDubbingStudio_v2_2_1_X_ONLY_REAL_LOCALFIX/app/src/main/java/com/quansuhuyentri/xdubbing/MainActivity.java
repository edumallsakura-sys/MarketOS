package com.quansuhuyentri.xdubbing;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 7001;
    private static final int REQ_PROJECTION = 7002;
    private static MainActivity current;

    private final ExecutorService io = Executors.newCachedThreadPool();
    private WebView webView;
    private MediaProjectionManager projectionManager;
    private TextToSpeech tts;
    private volatile boolean ttsReady;
    private long pendingMaxMs = 180000;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        current = this;
        projectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        initTts();
        initWebView();
    }

    private void initWebView() {
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                return !("https".equalsIgnoreCase(scheme) || "about".equalsIgnoreCase(scheme) || "file".equalsIgnoreCase(scheme));
            }
        });
        webView.addJavascriptInterface(new NativeApp(), "NativeApp");
        webView.loadUrl("file:///android_asset/app.html");
    }

    private void initTts() {
        tts = new TextToSpeech(this, status -> {
            ttsReady = status == TextToSpeech.SUCCESS;
            if (ttsReady) tts.setLanguage(Locale.US);
        });
    }

    private void requestSystemCapture(long maxMs) {
        pendingMaxMs = Math.max(5000, Math.min(maxMs, 3L * 60L * 60L * 1000L));
        if (Build.VERSION.SDK_INT < 29) {
            jsError("System audio capture requires Android 10+");
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_PROJECTION);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_PROJECTION);
            } else jsError("RECORD_AUDIO denied");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PROJECTION) return;
        if (resultCode != RESULT_OK || data == null) {
            jsError("MediaProjection denied");
            return;
        }
        Intent i = new Intent(this, PlaybackCaptureService.class);
        i.setAction(PlaybackCaptureService.ACTION_START);
        i.putExtra(PlaybackCaptureService.EXTRA_RESULT_CODE, resultCode);
        i.putExtra(PlaybackCaptureService.EXTRA_RESULT_DATA, data);
        i.putExtra(PlaybackCaptureService.EXTRA_MAX_MS, pendingMaxMs);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }

    static void sendAudioChunk(String base64, boolean isFinal) {
        MainActivity a = current;
        if (a == null || a.webView == null) return;
        String q = JSONObject.quote(base64 == null ? "" : base64);
        a.runOnUiThread(() -> a.webView.evaluateJavascript(
                "window.__x50OnAudioChunk&&window.__x50OnAudioChunk(" + q + "," + isFinal + ");", null));
    }

    static void sendAudioError(String message) {
        MainActivity a = current;
        if (a == null || a.webView == null) return;
        String q = JSONObject.quote(message == null ? "capture error" : message);
        a.runOnUiThread(() -> a.webView.evaluateJavascript(
                "window.__x50OnAudioError&&window.__x50OnAudioError(" + q + ");", null));
    }

    private void jsError(String message) { sendAudioError(message); }

    private void resolve(String id, JSONObject payload) {
        if (webView == null) return;
        String qi = JSONObject.quote(id == null ? "" : id);
        String qp = JSONObject.quote(payload == null ? "{}" : payload.toString());
        runOnUiThread(() -> webView.evaluateJavascript(
                "window.__nativeResolve&&window.__nativeResolve(" + qi + "," + qp + ");", null));
    }

    private JSONObject ok() { return new JSONObject(); }

    public final class NativeApp {
        @JavascriptInterface public void ttsSpeakAsync(String argsJson, String id) {
            runOnUiThread(() -> {
                JSONObject out = new JSONObject();
                try {
                    JSONObject args = new JSONObject(argsJson == null ? "{}" : argsJson);
                    String text = args.optString("text", "").trim();
                    String lang = args.optString("lang", "en-US");
                    float rate = (float) args.optDouble("rate", 0.9);
                    if (!ttsReady) throw new IllegalStateException("TTS not ready");
                    tts.setLanguage(Locale.forLanguageTag(lang));
                    tts.setSpeechRate(Math.max(0.5f, Math.min(rate, 1.5f)));
                    int r = tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "lm-" + System.currentTimeMillis());
                    out.put("ok", r == TextToSpeech.SUCCESS);
                } catch (Exception e) { try { out.put("ok", false).put("error", e.toString()); } catch (Exception ignored) {} }
                resolve(id, out);
            });
        }

        @JavascriptInterface public void ttsStopAsync(String argsJson, String id) {
            runOnUiThread(() -> {
                if (tts != null) tts.stop();
                JSONObject out = new JSONObject(); try { out.put("ok", true); } catch (Exception ignored) {}
                resolve(id, out);
            });
        }

        @JavascriptInterface public void translateAsync(String argsJson, String id) {
            io.execute(() -> {
                JSONObject out = new JSONObject();
                Translator translator = null;
                try {
                    JSONObject args = new JSONObject(argsJson == null ? "{}" : argsJson);
                    String text = args.optString("text", "").trim();
                    String to = args.optString("to", "vi").toLowerCase(Locale.ROOT);
                    String target = TranslateLanguage.fromLanguageTag(to);
                    if (target == null) target = TranslateLanguage.VIETNAMESE;
                    TranslatorOptions options = new TranslatorOptions.Builder()
                            .setSourceLanguage(TranslateLanguage.ENGLISH)
                            .setTargetLanguage(target).build();
                    translator = Translation.getClient(options);
                    Tasks.await(translator.downloadModelIfNeeded(new DownloadConditions.Builder().build()));
                    String translated = Tasks.await(translator.translate(text));
                    out.put("ok", true).put("translatedText", translated);
                } catch (Exception e) {
                    try { out.put("ok", false).put("error", e.toString()); } catch (Exception ignored) {}
                } finally { if (translator != null) translator.close(); }
                resolve(id, out);
            });
        }

        @JavascriptInterface public void httpPostAsync(String argsJson, String id) {
            io.execute(() -> {
                JSONObject out = new JSONObject();
                HttpURLConnection c = null;
                try {
                    JSONObject args = new JSONObject(argsJson == null ? "{}" : argsJson);
                    URL url = new URL(args.getString("url"));
                    c = (HttpURLConnection) url.openConnection();
                    c.setRequestMethod("POST"); c.setDoOutput(true); c.setConnectTimeout(20000); c.setReadTimeout(120000);
                    JSONObject headers = args.optJSONObject("headers");
                    if (headers != null) {
                        Iterator<String> it = headers.keys();
                        while (it.hasNext()) { String k = it.next(); c.setRequestProperty(k, headers.optString(k, "")); }
                    }
                    byte[] body = args.optString("body", "").getBytes(StandardCharsets.UTF_8);
                    try (OutputStream os = c.getOutputStream()) { os.write(body); }
                    int status = c.getResponseCode();
                    InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
                    StringBuilder sb = new StringBuilder();
                    if (in != null) try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                        String line; while ((line = br.readLine()) != null) sb.append(line).append('\n');
                    }
                    out.put("ok", status >= 200 && status < 300).put("status", status).put("body", sb.toString());
                    if (status < 200 || status >= 300) out.put("error", "HTTP " + status);
                } catch (Exception e) { try { out.put("ok", false).put("error", e.toString()); } catch (Exception ignored) {} }
                finally { if (c != null) c.disconnect(); }
                resolve(id, out);
            });
        }

        @JavascriptInterface public void fetchTranscriptAsync(String argsJson, String id) {
            JSONObject out = new JSONObject();
            try { out.put("ok", false).put("error", "No reliable native caption extractor; UI will use its real InnerTube/fallback pipeline"); }
            catch (Exception ignored) {}
            resolve(id, out);
        }

        @JavascriptInterface public void whisperTranscribeAsync(String argsJson, String id) {
            JSONObject out = new JSONObject();
            try { out.put("ok", false).put("error", "Use bundled Transformers.js Whisper or configured faster-whisper backend"); }
            catch (Exception ignored) {}
            resolve(id, out);
        }

        @JavascriptInterface public void extractMediaAsync(String argsJson, String id) {
            JSONObject out = new JSONObject();
            try { out.put("ok", false).put("error", "Direct X media extraction is not guaranteed; use System Audio capture for policy-permitted playback"); }
            catch (Exception ignored) {}
            resolve(id, out);
        }

        @JavascriptInterface public void startSystemAudioCapture(long maxMs) { runOnUiThread(() -> requestSystemCapture(maxMs)); }

        @JavascriptInterface public void stopSystemAudioCapture() {
            Intent i = new Intent(MainActivity.this, PlaybackCaptureService.class);
            i.setAction(PlaybackCaptureService.ACTION_STOP);
            startService(i);
        }
    }

    @Override protected void onDestroy() {
        current = null;
        io.shutdownNow();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
