package com.ytdubenglish.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Log;
import androidx.core.content.FileProvider;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Iterator;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * YT Dub English — WebView shell.
 * The whole app (UI + logic) lives in assets/index.html. This class only provides:
 *  - a secure JS bridge (postMessage, origin-locked) for native Android TTS
 *  - a native HTTP GET/POST relay so the WebView JS can fetch YouTube's watch-page /
 *    timedtext captions and the public Google Translate endpoint without hitting
 *    browser CORS restrictions (mirrors the approach used in the Lingua Mentor app).
 */
public class MainActivity extends Activity {
    private static final String TAG = "YTDubEnglish";
    private static final String APP_ORIGIN = "https://app.ytdubenglish.local";
    private static final String APP_BASE = APP_ORIGIN + "/assets/";
    private static final int REQ_FILE = 7101;
    private static final int MAX_HTTP_BYTES = 16 * 1024 * 1024;

    private WebView webView;
    private WebViewAssetLoader assetLoader;
    private ValueCallback<Uri[]> fileCallback;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private final ConcurrentHashMap<String, String> ttsPending = new ConcurrentHashMap<>();
    private final ExecutorService io = Executors.newFixedThreadPool(2);
    private final AtomicBoolean destroyed = new AtomicBoolean(false);

    private static final String BRIDGE_SCRIPT =
            "(function(){if(window.NativeApp)return;" +
            "var p={},seq=0;" +
            "function send(o){try{window.__YDENativePort.postMessage(JSON.stringify(o));}catch(e){}}" +
            "function call(m,a,t){return new Promise(function(resolve,reject){" +
            "var id='yde1-'+Date.now().toString(36)+'-'+(++seq).toString(36);" +
            "var timer=setTimeout(function(){if(p[id]){delete p[id];reject(new Error('native_timeout'));}},t||30000);" +
            "p[id]={resolve:resolve,reject:reject,timer:timer};send({method:m,args:a,id:id});});}" +
            "window.__YDEBridgeResolve=function(id,payload){var q=p[id];if(!q)return;delete p[id];clearTimeout(q.timer);" +
            "var x=payload;try{if(typeof x==='string')x=JSON.parse(x);}catch(e){}" +
            "if(x&&x.ok===false)q.reject(new Error(x.error||'native_error'));else q.resolve(x);};" +
            "window.NativeApp={" +
            "ttsSpeakAsync:function(a){return call('ttsSpeakAsync',a,60000);}," +
            "ttsStopAsync:function(a){return call('ttsStopAsync',a||{},5000);}," +
            "httpGetAsync:function(a){return call('httpGetAsync',a,65000);}," +
            "httpPostAsync:function(a){return call('httpPostAsync',a,65000);}," +
            "shareTextAsync:function(a){return call('shareTextAsync',a,15000);}};" +
            "var realFetch=window.fetch?window.fetch.bind(window):null;" +
            "if(realFetch){window.fetch=async function(input,init){try{return await realFetch(input,init);}catch(err){" +
            "init=init||{};var method=String(init.method||'GET').toUpperCase();" +
            "var url=typeof input==='string'?input:(input&&input.url)||'';" +
            "if(!/^https?:\\/\\//i.test(url))throw err;" +
            "var h={};try{new Headers(init.headers||{}).forEach(function(v,k){h[k]=v;});}catch(e){}" +
            "var r;if(method==='GET')r=await window.NativeApp.httpGetAsync({url:url,headers:h});" +
            "else if(method==='POST')r=await window.NativeApp.httpPostAsync({url:url,headers:h,body:typeof init.body==='string'?init.body:''});" +
            "else throw err;" +
            "return new Response((r&&r.body)||'',{status:Number(r&&r.status)||200,headers:{'Content-Type':(r&&r.contentType)||'application/json; charset=utf-8'}});" +
            "}};}" +
            "})();";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(16, 18, 28));
        getWindow().setNavigationBarColor(Color.rgb(16, 18, 28));
        initTts();
        setupWebView();
        setContentView(webView);
        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            loadBundledApp();
        }
    }

    private void initTts() {
        tts = new TextToSpeech(getApplicationContext(), status -> {
            ttsReady = status == TextToSpeech.SUCCESS;
            if (!ttsReady || tts == null) return;
            tts.setLanguage(Locale.US);
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) { }

                @Override public void onDone(String utteranceId) {
                    finishTtsRequest(utteranceId, true, null);
                }

                @Override public void onError(String utteranceId) {
                    finishTtsRequest(utteranceId, false, "tts_error");
                }

                @Override public void onError(String utteranceId, int errorCode) {
                    finishTtsRequest(utteranceId, false, "tts_error_" + errorCode);
                }

                @Override public void onStop(String utteranceId, boolean interrupted) {
                    finishTtsRequest(utteranceId, false, interrupted ? "tts_interrupted" : "tts_stopped");
                }
            });
        });
    }

    private void finishTtsRequest(String utteranceId, boolean ok, String error) {
        String bridgeId = ttsPending.remove(utteranceId);
        if (bridgeId == null) return;
        try {
            JSONObject result = new JSONObject();
            result.put("ok", ok);
            result.put("done", ok);
            if (!ok) result.put("error", error == null ? "tts_error" : error);
            resolve(bridgeId, result.toString());
        } catch (JSONException e) {
            resolve(bridgeId, jsonError("tts_result_error"));
        }
    }

    private void cancelPendingTts(String reason) {
        for (String utteranceId : ttsPending.keySet()) {
            String bridgeId = ttsPending.remove(utteranceId);
            if (bridgeId != null) resolve(bridgeId, jsonError(reason));
        }
    }

    private void loadBundledApp() {
        try (InputStream in = getAssets().open("index.html")) {
            String html = readBounded(in, 4 * 1024 * 1024);
            webView.loadDataWithBaseURL(APP_BASE, html, "text/html", "UTF-8", APP_BASE + "index.html");
        } catch (Exception e) {
            Log.e(TAG, "Failed to load bundled HTML", e);
            webView.loadUrl(APP_BASE + "index.html");
        }
    }

    private void setupWebView() {
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(16, 18, 28));
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setUserAgentString(s.getUserAgentString() + " YTDubEnglishAndroid/1.0.0");

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        assetLoader = new WebViewAssetLoader.Builder()
                .setDomain("app.ytdubenglish.local")
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        installSecureBridge();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                WebResourceResponse response = assetLoader.shouldInterceptRequest(request.getUrl());
                return response != null ? response : super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("app.ytdubenglish.local".equalsIgnoreCase(uri.getHost())) return false;
                String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.US);
                // Let YouTube's own iframe/embed traffic load inline inside the WebView.
                if (host.contains("youtube.com") || host.contains("youtube-nocookie.com") || host.contains("ytimg.com") || host.contains("googlevideo.com")) {
                    return false;
                }
                if (!request.isForMainFrame()) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    return true;
                } catch (Exception e) {
                    return false;
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                    view.evaluateJavascript(BRIDGE_SCRIPT, null);
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(intent, REQ_FILE);
                    return true;
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "Không mở được trình chọn file", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage cm) {
                Log.d(TAG, cm.message() + " @" + cm.lineNumber());
                return true;
            }
        });
    }

    private void installSecureBridge() {
        Set<String> origins = Collections.singleton(APP_ORIGIN);
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(webView, "__YDENativePort", origins,
                    (view, message, sourceOrigin, isMainFrame, replyProxy) -> {
                        if (!isMainFrame || sourceOrigin == null || !APP_ORIGIN.equals(sourceOrigin.toString())) return;
                        String data = message.getData();
                        if (data != null) dispatchBridgeMessage(data);
                    });
        } else {
            Toast.makeText(this, "Android System WebView quá cũ: native bridge bị tắt để bảo mật.", Toast.LENGTH_LONG).show();
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(webView, BRIDGE_SCRIPT, origins);
        }
    }

    private void dispatchBridgeMessage(String raw) {
        try {
            JSONObject message = new JSONObject(raw);
            String method = message.optString("method", "");
            String id = message.optString("id", "");
            JSONObject args = parseArgs(message.opt("args"));
            switch (method) {
                case "ttsSpeakAsync": ttsSpeak(args, id); break;
                case "ttsStopAsync": ttsStop(id); break;
                case "httpGetAsync": httpGet(args, id); break;
                case "httpPostAsync": httpPost(args, id); break;
                case "shareTextAsync": shareText(args, id); break;
                default: resolve(id, jsonError("unsupported_method:" + method));
            }
        } catch (Exception e) {
            Log.e(TAG, "Bridge message error", e);
        }
    }

    private JSONObject parseArgs(Object raw) {
        if (raw instanceof JSONObject) return (JSONObject) raw;
        if (raw instanceof String) {
            try { return new JSONObject((String) raw); }
            catch (Exception ignored) { }
        }
        return new JSONObject();
    }

    private void ttsSpeak(JSONObject args, String id) {
        runOnUiThread(() -> {
            try {
                String text = args.optString("text", "").trim();
                if (text.isEmpty()) { resolve(id, jsonError("empty_text")); return; }
                if (!ttsReady || tts == null) { resolve(id, jsonError("tts_initializing")); return; }

                String lang = args.optString("lang", "en-US");
                float rate = (float) Math.max(0.3, Math.min(2.0, args.optDouble("rate", 1.0)));
                int languageResult = tts.setLanguage(Locale.forLanguageTag(lang));
                if (languageResult == TextToSpeech.LANG_MISSING_DATA || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    resolve(id, jsonError("tts_language_not_supported:" + lang));
                    return;
                }
                tts.setSpeechRate(rate);

                try { tts.stop(); } catch (Exception ignored) { }
                cancelPendingTts("tts_replaced");

                String utteranceId = "yde1-" + System.nanoTime();
                ttsPending.put(utteranceId, id);
                int code = tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId);
                if (code != TextToSpeech.SUCCESS) {
                    ttsPending.remove(utteranceId);
                    resolve(id, jsonError("tts_speak_failed"));
                }
            } catch (Exception e) {
                resolve(id, jsonError(safeMessage(e)));
            }
        });
    }

    private void ttsStop(String id) {
        runOnUiThread(() -> {
            try { if (tts != null) tts.stop(); } catch (Exception ignored) { }
            cancelPendingTts("tts_stopped");
            resolve(id, "{\"ok\":true}");
        });
    }

    private void httpGet(JSONObject args, String id) {
        io.execute(() -> performHttp("GET", args, id));
    }

    private void httpPost(JSONObject args, String id) {
        io.execute(() -> performHttp("POST", args, id));
    }

    /**
     * Writes exported subtitle text (.srt / .vtt) to a cache file and opens the
     * system share sheet via FileProvider, so the user can save it anywhere
     * (Files, Drive, Telegram, etc.) or send it directly.
     */
    private void shareText(JSONObject args, String id) {
        io.execute(() -> {
            try {
                String filename = sanitizeFileName(args.optString("filename", "subtitle.srt"));
                String content = args.optString("content", "");
                String mime = args.optString("mime", "text/plain");
                if (content.isEmpty()) { resolve(id, jsonError("empty_content")); return; }

                File dir = new File(getCacheDir(), "shared");
                if (!dir.exists()) dir.mkdirs();
                File outFile = new File(dir, filename);
                try (FileOutputStream fos = new FileOutputStream(outFile)) {
                    fos.write(content.getBytes(StandardCharsets.UTF_8));
                }

                Uri uri = FileProvider.getUriForFile(MainActivity.this, "com.ytdubenglish.app.fileprovider", outFile);
                runOnUiThread(() -> {
                    try {
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType(mime);
                        send.putExtra(Intent.EXTRA_STREAM, uri);
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(send, "Chia sẻ / Lưu phụ đề"));
                        resolve(id, "{\"ok\":true}");
                    } catch (Exception e) {
                        resolve(id, jsonError(safeMessage(e)));
                    }
                });
            } catch (Exception e) {
                resolve(id, jsonError(safeMessage(e)));
            }
        });
    }

    private String sanitizeFileName(String name) {
        if (name == null || name.trim().isEmpty()) return "subtitle.srt";
        String clean = name.replaceAll("[^A-Za-z0-9._-]", "_");
        return clean.isEmpty() ? "subtitle.srt" : clean;
    }

    private void performHttp(String method, JSONObject args, String id) {
        HttpURLConnection connection = null;
        try {
            String url = args.optString("url", "").trim();
            if (!(url.startsWith("https://") || url.startsWith("http://"))) {
                throw new IllegalArgumentException("invalid_url");
            }
            String body = args.optString("body", "");
            JSONObject headers = args.optJSONObject("headers");

            connection = (HttpURLConnection) new URL(url).openConnection();
            connection.setRequestMethod(method);
            connection.setConnectTimeout(15_000);
            connection.setReadTimeout(method.equals("GET") ? 60_000 : 60_000);
            connection.setInstanceFollowRedirects(true);
            connection.setUseCaches(false);
            connection.setRequestProperty("Accept", "*/*");
            connection.setRequestProperty("Accept-Language", "en-US,en;q=0.9,vi;q=0.8");
            connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36");

            if (headers != null) {
                Iterator<String> it = headers.keys();
                while (it.hasNext()) {
                    String key = it.next();
                    String value = headers.optString(key, "");
                    if (!key.equalsIgnoreCase("Host") && !key.equalsIgnoreCase("Content-Length")) {
                        connection.setRequestProperty(key, value);
                    }
                }
            }

            if (method.equals("POST")) {
                byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
                connection.setDoOutput(true);
                connection.setFixedLengthStreamingMode(bytes.length);
                try (OutputStream out = connection.getOutputStream()) { out.write(bytes); }
            }

            int status = connection.getResponseCode();
            InputStream raw = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
            String response = raw == null ? "" : readBounded(raw, MAX_HTTP_BYTES);
            JSONObject result = new JSONObject();
            result.put("ok", status >= 200 && status < 300);
            result.put("status", status);
            result.put("body", response);
            result.put("contentType", connection.getContentType() == null ? "" : connection.getContentType());
            if (status < 200 || status >= 300) result.put("error", "HTTP " + status);
            resolve(id, result.toString());
        } catch (Exception e) {
            resolve(id, jsonError(e.getClass().getSimpleName() + ": " + safeMessage(e)));
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private String readBounded(InputStream in, int limit) throws Exception {
        try (BufferedInputStream input = new BufferedInputStream(in);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[16 * 1024];
            int total = 0, n;
            while ((n = input.read(buffer)) != -1) {
                total += n;
                if (total > limit) throw new IllegalStateException("response_too_large");
                output.write(buffer, 0, n);
            }
            return output.toString(StandardCharsets.UTF_8.name());
        }
    }

    private void resolve(String id, String payloadJsonString) {
        if (id == null || id.isEmpty() || destroyed.get()) return;
        runOnUiThread(() -> {
            if (webView == null || destroyed.get()) return;
            String js = "window.__YDEBridgeResolve&&window.__YDEBridgeResolve(" +
                    JSONObject.quote(id) + "," + JSONObject.quote(payloadJsonString) + ");";
            webView.evaluateJavascript(js, null);
        });
    }

    private String jsonError(String message) {
        try {
            JSONObject out = new JSONObject();
            out.put("ok", false);
            out.put("error", message == null ? "error" : message);
            return out.toString();
        } catch (JSONException e) {
            return "{\"ok\":false,\"error\":\"error\"}";
        }
    }

    private String safeMessage(Throwable error) {
        String message = error == null ? "error" : error.getMessage();
        return message == null || message.trim().isEmpty()
                ? (error == null ? "error" : error.getClass().getSimpleName())
                : message;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE) {
            ValueCallback<Uri[]> callback = fileCallback;
            fileCallback = null;
            if (callback != null) callback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        destroyed.set(true);
        try {
            if (tts != null) {
                tts.stop();
                cancelPendingTts("activity_destroyed");
                tts.shutdown();
            }
        } catch (Exception ignored) { }
        io.shutdownNow();
        if (webView != null) {
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.clearHistory();
            webView.removeAllViews();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
