# GitHub Actions build fix — 2026-09-24

This package fixes two CI problems without changing the app HTML/content:

1. `android-actions/setup-android@v3` -> `@v4` with `packages: 'platform-tools'`.
   This avoids the retired Android SDK `tools` package that causes sdkmanager exit code 1.
2. The persistent bootstrap now supports the preferred raw-upload flow:
   OneClick ZIP -> nested `*FULL_SOURCE.zip` -> Android Gradle project -> APK.

## Raw ZIP upload workflow
The repository must contain `.github/workflows/build-apk.yml` using the fixed
persistent bootstrap supplied separately as `build-apk-bootstrap-fixed.yml`.
After that one-time workflow replacement, upload the OneClick ZIP as-is.
