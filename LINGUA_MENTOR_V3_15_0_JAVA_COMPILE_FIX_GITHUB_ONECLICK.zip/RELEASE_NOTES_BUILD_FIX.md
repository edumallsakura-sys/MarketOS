# Build Fix

- No app feature removed or changed.
- Fixed GitHub Actions failure in `android-actions/setup-android@v3`.
- Migrated Android SDK setup to `android-actions/setup-android@v4`.
- Explicitly installs only supported `platform-tools` during action setup.
- Keeps Android platform 35 and Build Tools 35.0.0.
- Fixed persistent bootstrap to recursively open nested FULL_SOURCE ZIP.
- Keeps Java 17 / Gradle 8.9 / AGP 8.7.3.
