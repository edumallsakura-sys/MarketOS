package com.quansuhuyentri.xdubbing;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Base64;

import java.util.concurrent.atomic.AtomicBoolean;

public class PlaybackCaptureService extends Service {
    public static final String ACTION_START="xds.START_SYSTEM_AUDIO";
    public static final String ACTION_STOP="xds.STOP_SYSTEM_AUDIO";
    public static final String EXTRA_RESULT_CODE="resultCode";
    public static final String EXTRA_RESULT_DATA="resultData";
    public static final String EXTRA_MAX_MS="maxMs";
    private static final int SR=16000;
    private final AtomicBoolean running=new AtomicBoolean(false);
    private AudioRecord record; private MediaProjection projection; private Thread worker;

    @Override public void onCreate(){super.onCreate(); if(Build.VERSION.SDK_INT>=26){
        NotificationChannel ch=new NotificationChannel("xds_audio","System audio capture",NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
    }}

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null)return START_NOT_STICKY;
        if(ACTION_STOP.equals(intent.getAction())){stopCapture(true);return START_NOT_STICKY;}
        if(!ACTION_START.equals(intent.getAction())||running.get())return START_NOT_STICKY;
        Notification n=new Notification.Builder(this,"xds_audio").setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("X Dubbing Studio").setContentText("Capturing permitted system playback audio").setOngoing(true).build();
        if(Build.VERSION.SDK_INT>=29)startForeground(91,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);else startForeground(91,n);
        try{
            int code=intent.getIntExtra(EXTRA_RESULT_CODE,0);
            Intent data=Build.VERSION.SDK_INT>=33?intent.getParcelableExtra(EXTRA_RESULT_DATA,Intent.class):intent.getParcelableExtra(EXTRA_RESULT_DATA);
            long maxMs=intent.getLongExtra(EXTRA_MAX_MS,180000);
            MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection=m.getMediaProjection(code,data);
            projection.registerCallback(new MediaProjection.Callback(){@Override public void onStop(){stopCapture(true);}},new Handler(Looper.getMainLooper()));
            AudioPlaybackCaptureConfiguration cfg=new AudioPlaybackCaptureConfiguration.Builder(projection)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA).addMatchingUsage(AudioAttributes.USAGE_GAME).build();
            AudioFormat fmt=new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(SR).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build();
            int min=AudioRecord.getMinBufferSize(SR,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT);
            record=new AudioRecord.Builder().setAudioFormat(fmt).setBufferSizeInBytes(Math.max(min*4,32768)).setAudioPlaybackCaptureConfig(cfg).build();
            if(record.getState()!=AudioRecord.STATE_INITIALIZED)throw new IllegalStateException("AudioRecord init failed");
            record.startRecording();running.set(true);
            worker=new Thread(()->loop(maxMs),"xds-system-audio");worker.start();
        }catch(Exception e){MainActivity.sendAudioError(e.toString());stopCapture(false);}
        return START_NOT_STICKY;
    }

    private void loop(long maxMs){
        byte[] buf=new byte[32768]; long start=System.currentTimeMillis(); long bytes=0; long nonzero=0;
        try{
            while(running.get()&&System.currentTimeMillis()-start<maxMs){
                int n=record.read(buf,0,buf.length,AudioRecord.READ_BLOCKING);
                if(n<0)throw new IllegalStateException("AudioRecord read "+n);
                if(n==0)continue;
                bytes+=n; for(int i=0;i<n;i++)if(buf[i]!=0)nonzero++;
                String b64=Base64.encodeToString(buf,0,n,Base64.NO_WRAP);
                MainActivity.sendAudioChunk(b64,false);
            }
            double ratio=bytes==0?0:(double)nonzero/bytes;
            if(ratio<0.0005)MainActivity.sendAudioError("SILENT_OR_POLICY_BLOCKED: source app may disallow playback capture");
            else MainActivity.sendAudioChunk("",true);
        }catch(Exception e){MainActivity.sendAudioError(e.toString());}
        finally{stopCapture(false);}
    }

    private void stopCapture(boolean finalize){
        running.set(false);
        if(record!=null){try{record.stop();}catch(Exception ignored){} try{record.release();}catch(Exception ignored){} record=null;}
        if(projection!=null){try{projection.stop();}catch(Exception ignored){} projection=null;}
        if(finalize)MainActivity.sendAudioChunk("",true);
        stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();
    }
    @Override public void onDestroy(){stopCapture(false);super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
