# Upload / Build APK

Preferred existing workflow:
1. Keep the persistent repository workflow at `.github/workflows/build-apk.yml`.
2. Upload `LINGUA_MENTOR_V4_2_0_SEMANTIC_PAIR_LOCK_DUBBING_GITHUB_ONECLICK.zip` **as one ZIP file; do not extract it**.
3. Commit the ZIP.
4. Run **Build newest uploaded OneClick ZIP** in GitHub Actions.
5. Download artifact `LinguaMentor-v4.2.0-Semantic-Pair-Lock-Dubbing-APK`.

The outer ZIP contains a nested `*_ANDROID_FULL_SOURCE.zip`; the persistent bootstrap automatically opens nested ZIP layers until it finds the Android Gradle project.
