# Lingua Mentor v4.2.0 — Semantic Pair-Lock Dubbing

This build keeps the v4.1 Clean Core + Native Voice + YouTube pipeline and focuses deeply on the dubbing-learning loop requested from real-device testing.

## Core change: Semantic Pair-Lock
Every active dubbing unit is now treated as one immutable learning pair:

**English semantic segment → Vietnamese translation → one TTS utterance**

The screen and the Vietnamese voice read the same locked `pairKey`. The UI is not allowed to advance to another sentence while the previous Vietnamese TTS is still speaking.

## Semantic transcript improvements
- Removes obvious YouTube rolling-caption duplicates and suffix/prefix repetition before sentence building.
- Filters pure non-speech cues such as `[Music]` / `[Applause]`.
- Builds compact meaning units instead of merging by character count alone.
- Target segment is usually **8–17 English words**, with bounded hard guards around **21 words / ~7.2 seconds / ~128 characters**.
- Prefers punctuation and real pauses, and avoids ending on weak connector/function words when another safe boundary is available.
- When an old v4.1 lesson contains an oversized merged cue, v4.2 migrates/re-segments it on open.

## Natural Vietnamese translation
- If an API key is configured, only the CURRENT English segment is translated; PREVIOUS/NEXT are context only. The prompt explicitly forbids mixing neighboring sentences, adding ideas, omitting meaning, or repetitive filler.
- If no API key is configured, the engine prefers the Vietnamese YouTube translated-caption candidate aligned by timeline; only then falls back to MT.
- Translation is cached per exact pair hash and reused for display and speech.

## Dubbing synchronization
- **Live Pair-Lock:** video follows timestamps. If Vietnamese TTS reaches the end of the English pair and still has not finished, the player pauses at that boundary, finishes the exact displayed Vietnamese sentence, then resumes.
- **Stable Study:** original sentence completes, video pauses, the full Vietnamese pair is spoken, then playback resumes.
- TTS rate is kept in a narrower natural range (`0.88–1.32x` adaptive; user base control `0.85–1.25x`) instead of forcing very fast speech to hide timing errors.
- Translation prefetch is bounded: max 2 concurrent jobs and a capped queue. Duplicate pair jobs are coalesced.

## Learning UI
- Pair metadata shows pair number, English word count, duration, and translation source.
- `↺ Phát lại cặp hiện tại` seeks back to the exact segment.
- `🔊 Đọc lại câu Việt` speaks the exact Vietnamese text currently locked to that English pair.

## Android / build
- versionName `4.2.0`, versionCode `40200`
- Java 17, Android SDK 35, Build Tools 35.0.0
- Gradle 8.9, AGP 8.7.3, AndroidX WebKit 1.12.1
- `android-actions/setup-android@v4`
- Upload the outer OneClick ZIP to GitHub **without extracting it**. The persistent bootstrap can find and unpack the nested FULL_SOURCE ZIP automatically.

## Honest limits
- Sentence boundaries are derived from the real caption timestamps/text. Auto captions with poor punctuation can only be segmented heuristically; the app does not invent missing spoken words.
- Natural contextual Vietnamese is best when a configured AI translation provider is available. Without it, quality is limited by YouTube translated captions / MT fallback.
- Android device TTS is not voice cloning; voice naturalness depends on installed Speech Services / Vietnamese voice.
