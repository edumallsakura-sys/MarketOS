# Lingua Mentor v4.2.0 — release notes

## Dubbing quality: Semantic Pair-Lock
- Replaced v4.1 character/duration-only merge behavior with a semantic boundary engine.
- Rolling caption overlap is removed before grouping.
- Meaning-unit targets: 8–17 English words; bounded hard guards prevent oversized 30+ word cards like the device screenshot.
- Weak endings (`the`, `to`, `of`, `and`, auxiliaries, etc.) are penalized as split points; punctuation, pauses and new-clause starters are preferred.
- Existing v4.1 lessons auto-migrate when opened in Dubbing.

## EN ↔ VI ↔ voice integrity
- Each segment gets a stable pair hash.
- `displayEn`, `displayVi`, cached translation and TTS all resolve from the same pair.
- While TTS is active, the UI remains locked to that pair.
- Live mode uses an elastic tail pause if the Vietnamese sentence would otherwise overrun the English pair.

## Translation quality
- API translation now receives previous/current/next context, but is explicitly instructed to translate CURRENT only.
- Prompt requires natural spoken Vietnamese, complete meaning, concise wording, no additions, no omissions and no filler repetition.
- YouTube translated captions are aligned by temporal overlap and retained as the no-key candidate.
- Pair translations are cached and bounded.

## Performance / lifecycle
- Translation prefetch: max 2 concurrent requests.
- Queue capped at 24 and duplicate pair requests coalesced.
- Queued prefetch is cleared on dubbing teardown; active network work remains finite.
- Existing finite 250 ms visible-route player clock is retained and stops on navigation.

## Android build
- version `4.2.0`, versionCode `40200`.
- GitHub artifact: `LinguaMentor-v4.2.0-Semantic-Pair-Lock-Dubbing.apk`.
