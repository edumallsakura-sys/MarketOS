# YT Dub English: release minification is disabled for deterministic WebView shell builds.
