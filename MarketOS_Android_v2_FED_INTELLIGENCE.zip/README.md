# Market OS Android v2 — Fed Intelligence

Market OS v2 là dashboard Android dạng native WebView shell, ưu tiên dữ liệu thị trường, macro, crypto, risk và một **Fed Intelligence Center** dùng nguồn trực tiếp từ Board of Governors of the Federal Reserve System.

## Nâng cấp chính v2

- Fed Intelligence Center tự đồng bộ các RSS chính thức:
  - Monetary Policy: `https://www.federalreserve.gov/feeds/press_monetary.xml`
  - Speeches: `https://www.federalreserve.gov/feeds/speeches.xml`
  - Testimony: `https://www.federalreserve.gov/feeds/testimony.xml`
  - All Press Releases: `https://www.federalreserve.gov/feeds/press_all.xml`
  - Credit/Liquidity/Balance Sheet: `https://www.federalreserve.gov/feeds/clp.xml`
- Native Android tải/parses RSS nên không phụ thuộc CORS của WebView.
- Loại trùng theo URL, sắp xếp theo ngày và cache cục bộ.
- Gắn mức ưu tiên `CRITICAL/HIGH/NORMAL` theo loại tài liệu; đây là mức ưu tiên đọc, **không phải tín hiệu mua/bán**.
- Quick links tới FOMC Calendar, Beige Book, Monetary Policy Report và Financial Stability Report.
- Tab Fed riêng, lọc theo Monetary / Speech / Testimony / Liquidity / Critical.
- BTC/ETH vẫn dùng CoinGecko; nếu API lỗi app không giả giá demo mà hiển thị offline.

## Build APK bằng GitHub Actions

1. Giải nén ZIP và tải **toàn bộ nội dung bên trong thư mục project** lên root repository GitHub.
2. Vào tab **Actions** → workflow **Build Android APK** → Run workflow, hoặc push vào `main/master`.
3. Tải artifact `MarketOS-debug-apk`, bên trong có `app-debug.apk`.

Workflow dùng Java 17, Gradle 8.11.1 và Android Gradle Plugin 8.7.3.

## Bảo mật / giới hạn

- FRED/CoinGecko key được lưu ở localStorage của app. Với bản production nên chuyển secret sang Android Keystore hoặc backend proxy.
- Fed feed là dữ liệu công khai chính thức. App chỉ tổng hợp và xếp ưu tiên; không tuyên bố dự báo chắc chắn hay đảm bảo lợi nhuận.
- Bản v2 đồng bộ Fed khi mở app và khi bấm Đồng bộ. Theo dõi nền/notification 24/7 nên triển khai bằng WorkManager ở v3 để phù hợp giới hạn background của Android hiện đại.
