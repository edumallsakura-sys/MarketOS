# MarketOS v1 - no custom ProGuard rules yet.
