package com.marketos.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedInputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private static class FeedItem {
        String title = "";
        String link = "";
        String pubDate = "";
        String description = "";
        String source = "";
        long epoch = 0L;
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setUserAgentString(s.getUserAgentString() + " MarketOS/2.0");

        webView.addJavascriptInterface(new NativeBridge(), "MarketNative");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class NativeBridge {
        @JavascriptInterface
        public void refreshFed() {
            executor.execute(() -> {
                try {
                    List<FeedItem> all = new ArrayList<>();
                    all.addAll(fetchFeed("https://www.federalreserve.gov/feeds/press_monetary.xml", "Monetary Policy"));
                    all.addAll(fetchFeed("https://www.federalreserve.gov/feeds/speeches.xml", "Speech"));
                    all.addAll(fetchFeed("https://www.federalreserve.gov/feeds/testimony.xml", "Testimony"));
                    all.addAll(fetchFeed("https://www.federalreserve.gov/feeds/press_all.xml", "Press Release"));
                    all.addAll(fetchFeed("https://www.federalreserve.gov/feeds/clp.xml", "Liquidity/Balance Sheet"));

                    // De-duplicate by URL and prefer the most specific source fetched first.
                    List<FeedItem> unique = new ArrayList<>();
                    for (FeedItem item : all) {
                        boolean exists = false;
                        for (FeedItem u : unique) {
                            if (!item.link.isEmpty() && item.link.equals(u.link)) { exists = true; break; }
                        }
                        if (!exists) unique.add(item);
                    }
                    Collections.sort(unique, (a, b) -> Long.compare(b.epoch, a.epoch));

                    JSONArray arr = new JSONArray();
                    int limit = Math.min(unique.size(), 80);
                    for (int i = 0; i < limit; i++) {
                        FeedItem x = unique.get(i);
                        JSONObject o = new JSONObject();
                        o.put("title", x.title);
                        o.put("link", x.link);
                        o.put("pubDate", x.pubDate);
                        o.put("description", clean(x.description));
                        o.put("source", x.source);
                        o.put("importance", importance(x));
                        arr.put(o);
                    }
                    JSONObject payload = new JSONObject();
                    payload.put("ok", true);
                    payload.put("updatedAt", isoNow());
                    payload.put("items", arr);
                    sendFedPayload(payload.toString());
                } catch (Exception e) {
                    JSONObject payload = new JSONObject();
                    try {
                        payload.put("ok", false);
                        payload.put("error", e.getClass().getSimpleName() + ": " + e.getMessage());
                    } catch (Exception ignored) {}
                    sendFedPayload(payload.toString());
                }
            });
        }

        @JavascriptInterface
        public void openExternal(String url) {
            try {
                Uri u = Uri.parse(url);
                if ("https".equalsIgnoreCase(u.getScheme()) && u.getHost() != null && u.getHost().endsWith("federalreserve.gov")) {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                }
            } catch (Exception ignored) {}
        }
    }

    private void sendFedPayload(String json) {
        final String encoded = JSONObject.quote(json);
        runOnUiThread(() -> webView.evaluateJavascript("window.onFedPayload(JSON.parse(" + encoded + "));", null));
    }

    private List<FeedItem> fetchFeed(String urlString, String source) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(urlString).openConnection();
        c.setConnectTimeout(12000);
        c.setReadTimeout(15000);
        c.setRequestProperty("User-Agent", "MarketOS/2.0 Android");
        c.setRequestProperty("Accept", "application/rss+xml, application/xml, text/xml, */*");
        if (c.getResponseCode() < 200 || c.getResponseCode() >= 300) {
            throw new IllegalStateException("Fed feed HTTP " + c.getResponseCode());
        }

        XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
        factory.setNamespaceAware(false);
        XmlPullParser p = factory.newPullParser();
        p.setInput(new BufferedInputStream(c.getInputStream()), "UTF-8");

        List<FeedItem> out = new ArrayList<>();
        FeedItem current = null;
        String tag = "";
        int event = p.getEventType();
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                tag = p.getName().toLowerCase(Locale.US);
                if ("item".equals(tag)) current = new FeedItem();
            } else if (event == XmlPullParser.TEXT && current != null) {
                String text = p.getText();
                if (text != null) {
                    if ("title".equals(tag)) current.title += text;
                    else if ("link".equals(tag)) current.link += text;
                    else if ("pubdate".equals(tag)) current.pubDate += text;
                    else if ("description".equals(tag)) current.description += text;
                }
            } else if (event == XmlPullParser.END_TAG) {
                String end = p.getName().toLowerCase(Locale.US);
                if ("item".equals(end) && current != null) {
                    current.source = source;
                    current.title = clean(current.title);
                    current.link = current.link.trim();
                    current.pubDate = current.pubDate.trim();
                    current.epoch = parseRssDate(current.pubDate);
                    out.add(current);
                    current = null;
                }
                tag = "";
            }
            event = p.next();
        }
        c.disconnect();
        return out;
    }

    private static String clean(String s) {
        if (s == null) return "";
        return s.replaceAll("<[^>]+>", " ")
                .replace("&nbsp;", " ").replace("&amp;", "&")
                .replace("&quot;", "\"").replace("&#39;", "'")
                .replaceAll("\\s+", " ").trim();
    }

    private static long parseRssDate(String value) {
        if (value == null) return 0L;
        String[] patterns = {"EEE, dd MMM yyyy HH:mm:ss z", "EEE, dd MMM yyyy HH:mm z", "MM/dd/yyyy"};
        for (String pattern : patterns) {
            try {
                SimpleDateFormat f = new SimpleDateFormat(pattern, Locale.US);
                Date d = f.parse(value.trim());
                if (d != null) return d.getTime();
            } catch (Exception ignored) {}
        }
        return 0L;
    }

    private static String importance(FeedItem x) {
        String t = (x.title + " " + x.source).toLowerCase(Locale.US);
        if (t.contains("fomc") || t.contains("minutes") || t.contains("monetary policy report") ||
            t.contains("projection") || t.contains("federal funds") || t.contains("beige book")) return "CRITICAL";
        if (t.contains("chair") || t.contains("economic outlook") || t.contains("testimony") ||
            t.contains("balance sheet") || t.contains("liquidity")) return "HIGH";
        return "NORMAL";
    }

    private static String isoNow() {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US);
        f.setTimeZone(TimeZone.getDefault());
        return f.format(new Date());
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
