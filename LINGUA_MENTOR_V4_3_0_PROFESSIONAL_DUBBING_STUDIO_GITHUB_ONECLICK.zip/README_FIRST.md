# Lingua Mentor v4.3.0 — Professional Dubbing Studio

This build keeps the v4.2 Clean Core + Semantic Pair-Lock engine and focuses on the small but important caption-boundary failures seen on real YouTube auto captions.

## What changed

### 1. Surgical Boundary Repair — do not disturb good captions
The app no longer reworks every subtitle just because one local area is bad. It reuses the v4.2 semantic transcript, then repairs only suspicious boundaries such as:
- a pair ending in a dangling question starter or connector (`what`, `how can I`, `to`, `and`, etc.),
- a new proposition accidentally trapped inside the same rolling-caption block,
- adjacent final pairs whose timestamps overlap.

The repair moves existing caption words only. It does not invent missing spoken words.

### 2. Monotonic pair timeline
Final learning pairs are normalized so adjacent pairs do not overlap. Overlapping YouTube display windows are split at the overlap region, preventing one spoken fragment from appearing in two study pairs.

### 3. Professional translation QA
- One immutable unit remains: **English pair → Vietnamese pair → one TTS utterance**.
- Old good translations are carried forward when the English word sequence is unchanged.
- Changed/suspicious pairs are translated again instead of reusing a mismatched rolling-caption translation.
- Translation candidates that are implausibly long, duplicated, or structurally mismatched are rejected.
- With an API key, PREVIOUS/NEXT are context only; CURRENT alone may appear in the Vietnamese output.
- Without an API key, the app may use a quality-gated YouTube Vietnamese candidate or exact-pair MT fallback.

### 4. Professional Dubbing viewer
The live dubbing screen now adds:
- Pair-Lock / source / progress badges,
- next-pair preview,
- previous / replay / next transport,
- replay Vietnamese,
- retranslate current pair,
- direct jump to transcript.

If TTS is still speaking at the end of a pair, the video remains held at that boundary until the exact displayed Vietnamese line is finished.

### 5. Professional transcript viewer
Long videos can contain 1,000+ caption units. Rendering all of them at once is wasteful on Android. v4.3 uses 30-pair pages, bounded translation prefetch, compact EN/VI cards, and per-pair listen / speak / retranslate controls.

## Example repaired pattern
A rolling-caption sequence like:
- `... in my relationships what`
- `Advice can you give me people often say ... how can I`
- `be more confident ...`

is repaired into meaningful non-overlapping pairs such as:
- `... in my relationships?`
- `What advice can you give me?`
- `People often say to me I don't feel confident.`
- `How can I be more confident ...?`

No spoken words are added; only boundary placement and punctuation are repaired.

## Android / build
- versionName `4.3.0`, versionCode `40300`
- Java 17, Android SDK 35, Build Tools 35.0.0
- Gradle 8.9, AGP 8.7.3, AndroidX WebKit 1.12.1
- `android-actions/setup-android@v4`
- Upload the outer OneClick ZIP to GitHub **without extracting it**. The persistent bootstrap finds the nested FULL_SOURCE ZIP automatically.

## Runtime discipline
- no infinite polling/network retry loop,
- dubbing poll remains bounded and stops outside the dubbing route,
- translation concurrency remains capped at 2,
- queue remains bounded,
- transcript DOM is paged,
- native TTS/WebView cleanup remains lifecycle-aware.

## Honest limits
- Auto-caption text can itself be wrong; the app repairs boundaries but does not fabricate missing speech.
- Natural Vietnamese is best with a configured AI provider. Offline/device TTS quality depends on the installed Android speech voice.
