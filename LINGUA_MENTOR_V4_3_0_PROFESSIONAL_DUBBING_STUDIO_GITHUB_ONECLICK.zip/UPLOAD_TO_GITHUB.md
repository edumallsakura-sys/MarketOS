# Upload / build

1. Upload **LINGUA_MENTOR_V4_3_0_PROFESSIONAL_DUBBING_STUDIO_GITHUB_ONECLICK.zip** to the GitHub repository **as-is**. Do not extract it.
2. Keep the persistent `.github/workflows/build-apk.yml` bootstrap in the repository. The fixed bootstrap uses `android-actions/setup-android@v4` and understands nested `*FULL_SOURCE.zip` packages.
3. Run **Actions → Build newest uploaded OneClick ZIP → Run workflow**.
4. Download artifact **LinguaMentor-v4.3.0-Professional-Dubbing-Studio-APK**.
