# Release notes — v4.3.0 Professional Dubbing Studio

Focused real-device fix for isolated bad subtitle regions in otherwise-good YouTube transcripts.

- Added surgical dangling-tail repair (`what`, `how can I`, connectors, auxiliaries).
- Added high-confidence internal proposition splitting for rolling captions.
- Added final monotonic timestamp repair so adjacent Pair-Lock units do not overlap.
- Preserves translations for unchanged good pairs; invalidates only changed pairs.
- Added translation quality gate for repeated/oversized candidate text.
- Upgraded AI dubbing prompt for exact CURRENT-only translation and natural Vietnamese delivery.
- Added professional dubbing transport, next-pair preview, progress, source/quality status, and one-tap retranslate.
- Rebuilt transcript viewer as 30-pair pages to avoid 1,000+ DOM-card screens on Android.
- Kept v4.2 Pair-Lock invariant: displayed English, displayed Vietnamese, and spoken Vietnamese remain the same active pair.
