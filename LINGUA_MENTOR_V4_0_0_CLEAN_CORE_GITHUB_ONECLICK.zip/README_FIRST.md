# Lingua Mentor v4.0.0 Clean Core — Android source

This Android project packages the supplied upgraded **Lingua Mentor • v4.0 Clean Core** HTML as the app UI.

## Important
- `app/src/main/assets/index.html` is copied byte-for-byte from the supplied upgraded HTML.
- Android native shell provides secure origin-scoped Native TTS matching the v4 Promise-style `ttsSpeakAsync()` call.
- File picker supports the HTML's SRT/VTT/TXT transcript import and JSON backup import.
- The HTML's Gemini/OpenAI-compatible `fetch()` is preserved; if WebView CORS blocks a POST, a bounded native HTTP fallback is attempted.
- No microphone, MediaProjection, background service, or storage permission is requested by this Clean Core package.
- WebView is destroyed and worker threads/TTS are shut down with the Activity lifecycle.

## Build
GitHub Actions: `.github/workflows/build-apk.yml`
- Java 17
- setup-android v4
- Android SDK 35 / build-tools 35.0.0
- Gradle 8.9
- AGP 8.7.3

For the user's existing raw-ZIP flow, keep the persistent bootstrap workflow at repository path `.github/workflows/build-apk.yml`, upload the outer OneClick ZIP **without extracting it**, and run Actions.
