# Lingua Mentor v4.0.0 Clean Core — APK packaging

- Based on the newly supplied upgraded HTML: `Lingua Mentor • v4.0 Clean Core`.
- App version: 4.0.0 / versionCode 40000.
- Preserves the upgraded HTML byte-for-byte in Android assets.
- Native TTS bridge adapted to the v4 HTML's Promise-style call signature.
- Added safe file chooser for transcript and backup import.
- Added bounded native POST fallback for API CORS failures; direct browser fetch remains first choice.
- Removed legacy microphone/system-audio capture permissions and service because the v4 Clean Core HTML does not call them.
- Uses `android-actions/setup-android@v4` to avoid the retired SDK tools-package failure.
