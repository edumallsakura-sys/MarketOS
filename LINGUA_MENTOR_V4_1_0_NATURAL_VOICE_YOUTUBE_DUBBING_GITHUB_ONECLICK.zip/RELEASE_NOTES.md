# Lingua Mentor v4.1.0 — release notes

## Learning audio repair
- Removed the active pass-2 fixed-speed behavior (`0.75x`).
- Speed slider now controls all passes, replay, and Shadowing ×5.
- Native TTS Promise resolves on actual utterance completion rather than when speech is merely queued.
- Stop/replacement cancels the previous utterance cleanly.
- Local MP3 is a last fallback only when assets are genuinely packaged.

## YouTube playback / error 153
- Android loads the bundled app with `WebView.loadDataWithBaseURL()` at `https://app.luyennghe.local/assets/`.
- Iframes include `enablejsapi=1`, `origin`, `widget_referrer`, and `referrerpolicy=strict-origin-when-cross-origin`.
- This targets the missing-Referer/client-identification cause of YouTube error 153.

## YouTube Dubbing v4.1
- Real caption acquisition: YouTube player response → selected English caption track → JSON3/VTT/XML parser.
- Vietnamese translated track used when YouTube exposes it; otherwise translation uses configured API and a bounded public fallback.
- Caption cleanup + sentence merge preserves real timestamps.
- Translation prefetch for upcoming cues.
- Live Sync: muted original by default, timestamp-following, adaptive TTS pace.
- Stable: original sentence finishes → pause → read full Vietnamese sentence → resume.
- Busy/token guards prevent overlapping or stale TTS.
- Polling is limited to the visible dubbing route and cleaned up on navigation / Activity destroy.

## Android shell
- Version `4.1.0`, versionCode `40100`.
- Native TTS, bounded HTTP GET/POST, file chooser, lifecycle cleanup.
- Java 17 / SDK 35 / WebKit 1.12.1.
