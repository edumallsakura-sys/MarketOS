# Lingua Mentor v4.1.0 — Natural Voice + YouTube Dubbing

Android project generated from the supplied **Lingua Mentor v4.0 Clean Core** and upgraded specifically for the device issues shown on 24-09-2026.

## What changed
- Learning voice path is now **Android Native TTS first → Web Speech fallback → packaged MP3 only if it really exists**. The v4.0 package did not contain `audio/phrases/*.mp3`, so the app no longer waits for a nonexistent local MP3 before speaking.
- One speed value controls every learning pass. The old hidden `0.75x` override in pass 2 was removed from the active renderer.
- Shadowing ×5 waits for the native `TextToSpeech` `onDone` callback before starting the next repetition, preventing clipped/replaced speech.
- YouTube WebView uses an HTTPS base URL, `strict-origin-when-cross-origin`, `origin`, and `widget_referrer` so embedded playback has client identity / Referer required by YouTube.
- Video Studio adds automatic caption acquisition (real caption tracks only), SRT/VTT fallback, sentence merge, translation prefetch, and a dedicated YouTube Dubbing screen.
- Dubbing has two modes: **Live Sync** and **Stable**. Live Sync follows timestamps and adapts TTS speed; Stable waits for the original sentence, pauses, reads the full Vietnamese sentence, then resumes.
- Original audio can be toggled. Live Sync defaults it OFF to prevent two voices speaking over each other.
- Caption/API network requests have bounded native GET/POST fallbacks for WebView CORS failures.
- No fabricated transcript: if no usable caption track is available, the user is asked for SRT/VTT.

## Build
GitHub Actions: `.github/workflows/build-apk.yml`
- Java 17
- `android-actions/setup-android@v4`
- Android SDK 35 / build-tools 35.0.0
- Gradle 8.9
- AGP 8.7.3

For the established raw-ZIP workflow, keep a persistent `.github/workflows/build-apk.yml` in the repository, upload the outer OneClick ZIP **without extracting it**, then run Actions. A refreshed persistent bootstrap is included as `PERSISTENT_BOOTSTRAP_build-apk.yml`.

## Honest limits
- This package does not contain 1,000 prerecorded MP3 phrase files; it uses Android TTS / Web Speech for reliable offline-ish playback when device voices are installed.
- YouTube caption extraction depends on public/accessible caption tracks and can change when YouTube changes internal endpoints. SRT/VTT remains the deterministic fallback.
- Device TTS is not voice cloning. Naturalness depends on the installed Android voice.
