# Upload this ZIP as-is

1. Do NOT extract `LINGUA_MENTOR_V4_1_0_NATURAL_VOICE_YOUTUBE_DUBBING_GITHUB_ONECLICK.zip` before uploading it to the repository.
2. Keep the persistent workflow at `.github/workflows/build-apk.yml` in the repository. If it is still an older bootstrap, replace it once with `PERSISTENT_BOOTSTRAP_build-apk.yml` from this package (rename to `build-apk.yml`).
3. Commit the new OneClick ZIP, then run GitHub Actions `Build newest uploaded OneClick ZIP`.
4. Download artifact `LinguaMentor-v4.1.0-NaturalVoice-Dubbing-APK`.
