# Lattice Notes

Ứng dụng Android ghi chú đa phương tiện và liên kết kiến thức, hoạt động hoàn toàn ngoại tuyến.

## Chức năng
- Ghi chú văn bản, câu nói, ảnh và bản thu âm (tối đa 10 phút / 25 MB).
- Tìm kiếm gần đúng không dấu, sửa lỗi nhẹ, mở rộng nhóm từ đồng nghĩa, ưu tiên tiêu đề/thẻ.
- Module **Liên kết** tự phát hiện ghi chú liên quan bằng độ tương đồng nội dung và thẻ.
- Ghim ghi chú bằng thao tác nhấn giữ; phát lại âm thanh ngay trong trình biên tập.
- Dữ liệu lưu trong bộ nhớ riêng của ứng dụng; không dùng Internet, không API key.
- Giao diện sáng/tối, trạng thái loading/empty/error/retry; thao tác I/O có timeout và giới hạn.

## Yêu cầu
- Android Studio Ladybug hoặc mới hơn.
- JDK 17.
- Android SDK 35 / Build Tools 35.0.0.
- Thiết bị Android 8.0 (API 26) trở lên.

## Build
```bash
./gradlew clean assembleDebug
```
APK: `app/build/outputs/apk/debug/app-debug.apk`

Release APK tạo bởi `assembleRelease` chưa được ký phát hành. Để đưa lên Play Store, cấu hình signing riêng bằng GitHub Secrets hoặc `keystore.properties` cục bộ; không commit keystore/mật khẩu.

## Quyền riêng tư và giới hạn
- Chỉ xin `RECORD_AUDIO` khi người dùng bắt đầu thu âm.
- Không có quyền mạng, camera, đọc toàn bộ thư viện hoặc định vị.
- Trình chọn tệp hệ thống chỉ cấp quyền cho đúng tệp người dùng chọn.
- Tìm kiếm/ngữ nghĩa chạy trên thiết bị, không dùng mô hình cloud. Độ liên quan dựa trên chuẩn hóa tiếng Việt/Anh, từ gần nghĩa, n-gram, nội dung và thẻ; với chủ đề đặc thù nên thêm thẻ/mô tả.
- Khi gỡ ứng dụng, dữ liệu cục bộ có thể bị xóa; Android Backup được bật cho database và tệp đính kèm.
