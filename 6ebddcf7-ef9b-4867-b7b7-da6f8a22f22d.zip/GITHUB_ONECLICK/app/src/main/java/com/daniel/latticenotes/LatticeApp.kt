package com.daniel.latticenotes

import android.app.Application

class LatticeApp : Application() {
    lateinit var repository: NoteRepository
        private set
    override fun onCreate() {
        super.onCreate()
        repository = NoteRepository(this)
    }
}
