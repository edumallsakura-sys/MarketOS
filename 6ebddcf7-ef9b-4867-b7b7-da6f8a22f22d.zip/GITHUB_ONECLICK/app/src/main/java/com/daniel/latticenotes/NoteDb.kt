package com.daniel.latticenotes

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class NoteDb(context: Context) : SQLiteOpenHelper(context, "lattice_notes.db", null, 1) {
    override fun onConfigure(db: SQLiteDatabase) { super.onConfigure(db); db.setForeignKeyConstraintsEnabled(true) }
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE notes(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL CHECK(length(title) BETWEEN 1 AND 200),
            body TEXT NOT NULL DEFAULT '', tags TEXT NOT NULL DEFAULT '', transcript TEXT NOT NULL DEFAULT '',
            attachment_path TEXT, attachment_mime TEXT, pinned INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)""")
        db.execSQL("CREATE INDEX idx_notes_updated ON notes(updated_at DESC)")
        db.execSQL("CREATE INDEX idx_notes_pinned ON notes(pinned, updated_at DESC)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun all(limit: Int = 2000): List<Note> = readableDatabase.query(
        "notes", null, null, null, null, null, "updated_at DESC", limit.coerceIn(1, 2000).toString()
    ).use { c -> buildList { while (c.moveToNext()) add(c.toNote()) } }

    fun upsert(note: Note): Long {
        val now = System.currentTimeMillis()
        val cv = ContentValues().apply {
            put("title", note.title.trim().take(200)); put("body", note.body.take(50_000))
            put("tags", note.tags.take(1_000)); put("transcript", note.transcript.take(10_000))
            put("attachment_path", note.attachmentPath); put("attachment_mime", note.attachmentMime)
            put("pinned", if (note.pinned) 1 else 0); put("updated_at", now)
            if (note.id == 0L) put("created_at", now)
        }
        return writableDatabase.beginTransaction().let {
            try {
                val id = if (note.id == 0L) writableDatabase.insertOrThrow("notes", null, cv)
                else { writableDatabase.update("notes", cv, "id=?", arrayOf(note.id.toString())); note.id }
                writableDatabase.setTransactionSuccessful(); id
            } finally { writableDatabase.endTransaction() }
        }
    }

    fun delete(id: Long) { writableDatabase.delete("notes", "id=?", arrayOf(id.toString())) }
    fun togglePin(id: Long, pinned: Boolean) {
        writableDatabase.update("notes", ContentValues().apply { put("pinned", if (pinned) 1 else 0) }, "id=?", arrayOf(id.toString()))
    }

    private fun Cursor.toNote() = Note(
        id = getLong(getColumnIndexOrThrow("id")), title = getString(getColumnIndexOrThrow("title")),
        body = getString(getColumnIndexOrThrow("body")), tags = getString(getColumnIndexOrThrow("tags")),
        transcript = getString(getColumnIndexOrThrow("transcript")),
        attachmentPath = getStringOrNull("attachment_path"), attachmentMime = getStringOrNull("attachment_mime"),
        pinned = getInt(getColumnIndexOrThrow("pinned")) == 1,
        createdAt = getLong(getColumnIndexOrThrow("created_at")), updatedAt = getLong(getColumnIndexOrThrow("updated_at"))
    )
    private fun Cursor.getStringOrNull(column: String): String? { val i=getColumnIndexOrThrow(column); return if(isNull(i)) null else getString(i) }
}
