package com.daniel.latticenotes

import java.text.Normalizer
import kotlin.math.max
import kotlin.math.sqrt

object SearchEngine {
    private val stop = setOf("va","la","cua","cho","mot","nhung","cac","voi","trong","the","thi","and","the","for","from","this","that")
    private val synonymGroups = listOf(
        setOf("tien","money","cash","von","thanhkhoan"), setOf("hoc","learn","study","giaoduc","kienthuc"),
        setOf("viec","work","job","nghenghiep","congviec"), setOf("yeu","love","tinhyeu","thuong"),
        setOf("y","idea","ytuong","sangkien"), setOf("anh","image","photo","hinh"),
        setOf("amthanh","audio","voice","giongnoi","thuam"), setOf("sach","book","doc","reading"),
        setOf("kinhte","economy","economic","macro","vimo"), setOf("tamly","psychology","camxuc","emotion")
    )
    private val synonymMap = buildMap { synonymGroups.forEach { g -> g.forEach { put(it, g) } } }

    fun normalize(raw: String): String = Normalizer.normalize(raw.lowercase(), Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "").replace('đ','d').replace(Regex("[^a-z0-9]+"), " ").trim()

    private fun tokens(raw: String): Set<String> = normalize(raw).split(' ').asSequence()
        .filter { it.length > 1 && it !in stop }.flatMap { sequenceOf(it) + (synonymMap[it]?.asSequence() ?: emptySequence()) }.take(600).toSet()

    fun search(notes: List<Note>, query: String, limit: Int = 50): List<Note> {
        if (query.isBlank()) return notes.take(limit)
        val qNorm = normalize(query); val qTokens = tokens(query)
        return notes.asSequence().map { n ->
            val title = normalize(n.title); val all = normalize(n.searchable); val nTokens = tokens(n.searchable)
            val overlap = qTokens.intersect(nTokens).size.toDouble() / max(1, qTokens.size)
            val titleHit = if (title.contains(qNorm)) 2.5 else 0.0
            val phraseHit = if (all.contains(qNorm)) 1.4 else 0.0
            val fuzzy = qTokens.maxOfOrNull { q -> nTokens.maxOfOrNull { similarity(q,it) } ?: 0.0 } ?: 0.0
            n.copy(score = titleHit + phraseHit + overlap * 3.0 + fuzzy)
        }.filter { it.score >= 0.72 }.sortedWith(compareByDescending<Note>{it.score}.thenByDescending{it.updatedAt}).take(limit).toList()
    }

    fun withRelations(notes: List<Note>, limit: Int = 200): List<Note> {
        val bounded = notes.take(500)
        return bounded.map { a ->
            val ranked = bounded.asSequence().filter { it.id != a.id }.map { b -> relatedness(a,b) }.count { it >= .22 }
            a.copy(relationCount = ranked.coerceAtMost(99))
        }.filter { it.relationCount > 0 }.sortedWith(compareByDescending<Note>{it.relationCount}.thenByDescending{it.updatedAt}).take(limit)
    }

    fun relatedTo(note: Note, notes: List<Note>, limit: Int = 8): List<Note> = notes.asSequence().filter { it.id != note.id }
        .map { it.copy(score = relatedness(note,it)) }.filter { it.score >= .18 }.sortedByDescending { it.score }.take(limit).toList()

    private fun relatedness(a: Note, b: Note): Double {
        val aa=tokens(a.searchable); val bb=tokens(b.searchable); if(aa.isEmpty()||bb.isEmpty()) return 0.0
        val cosine=aa.intersect(bb).size / sqrt((aa.size*bb.size).toDouble())
        val tagsA=tokens(a.tags); val tagsB=tokens(b.tags); val tagBoost=if(tagsA.intersect(tagsB).isNotEmpty()) .35 else 0.0
        return (cosine+tagBoost).coerceAtMost(1.0)
    }

    private fun similarity(a:String,b:String):Double {
        if(a==b) return 1.0; if(a.length<3||b.length<3) return 0.0
        val ga=a.windowed(3).toSet(); val gb=b.windowed(3).toSet(); return 2.0*ga.intersect(gb).size/(ga.size+gb.size)
    }
}
