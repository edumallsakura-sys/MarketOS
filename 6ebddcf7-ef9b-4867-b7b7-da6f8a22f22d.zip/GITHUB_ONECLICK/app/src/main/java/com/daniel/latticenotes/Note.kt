package com.daniel.latticenotes

data class Note(
    val id: Long = 0,
    val title: String,
    val body: String = "",
    val tags: String = "",
    val transcript: String = "",
    val attachmentPath: String? = null,
    val attachmentMime: String? = null,
    val pinned: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val relationCount: Int = 0,
    val score: Double = 0.0
) {
    val searchable: String get() = "$title $body $tags $transcript"
}
