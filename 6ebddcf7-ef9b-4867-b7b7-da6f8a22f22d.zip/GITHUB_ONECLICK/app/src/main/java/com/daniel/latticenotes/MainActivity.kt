package com.daniel.latticenotes

import android.Manifest
import android.app.Dialog
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.inputmethod.InputMethodManager
import android.content.Context
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.daniel.latticenotes.databinding.ActivityMainBinding
import com.daniel.latticenotes.databinding.DialogEditorBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var b:ActivityMainBinding
    private val repo get()=(application as LatticeApp).repository
    private lateinit var adapter:NoteAdapter
    private var loadJob:Job?=null
    private var tab=0
    private var editor:EditorSession?=null
    private var recorder:MediaRecorder?=null
    private var player:MediaPlayer?=null

    private val pickFile=registerForActivityResult(ActivityResultContracts.GetContent()){ uri:Uri? -> uri?.let{ importAttachment(it) } }
    private val audioPermission=registerForActivityResult(ActivityResultContracts.RequestPermission()){ granted ->
        if(granted) startRecording() else message("Cần quyền micro để thu âm. Bạn vẫn có thể đính kèm tệp âm thanh.")
    }

    override fun onCreate(state:Bundle?){ super.onCreate(state); b=ActivityMainBinding.inflate(layoutInflater); setContentView(b.root)
        adapter=NoteAdapter(::openEditor,::togglePin); b.list.layoutManager=LinearLayoutManager(this); b.list.adapter=adapter
        listOf("Tất cả","Liên kết","Đã ghim").forEach{b.tabs.addTab(b.tabs.newTab().setText(it))}
        b.tabs.addOnTabSelectedListener(object:TabLayout.OnTabSelectedListener{
            override fun onTabSelected(t:TabLayout.Tab){tab=t.position; b.title.text=when(tab){1->"Liên kết kiến thức";2->"Đã ghim";else->"Kho tri thức"}; refresh()}
            override fun onTabUnselected(t:TabLayout.Tab)=Unit; override fun onTabReselected(t:TabLayout.Tab)=Unit
        })
        b.searchInput.doAfterTextChanged{ loadJob?.cancel(); loadJob=lifecycleScope.launch{delay(280); refresh()} }
        b.addButton.setOnClickListener{openEditor(null)}
        refresh()
    }

    private fun refresh(){ loadJob?.cancel(); val query=b.searchInput.text?.toString().orEmpty(); loadJob=lifecycleScope.launch{
        setLoading(true); try{
            val all=when(tab){1->repo.links(); else->if(query.isBlank()) repo.list() else repo.search(query)}
            val rows=when(tab){2->all.filter{it.pinned};1->if(query.isBlank()) all else SearchEngine.search(all,query);else->all}
            adapter.submitList(rows); showEmpty(rows.isEmpty(),query)
        }catch(_:CancellationException){}catch(e:Throwable){ showEmpty(true,query,"Không thể đọc kho ghi chú"); Snackbar.make(b.root,e.message?:"Đã có lỗi",Snackbar.LENGTH_INDEFINITE).setAction("Thử lại"){refresh()}.show() }
        finally{setLoading(false)}
    }}
    private fun setLoading(v:Boolean){b.progress.visibility=if(v)View.VISIBLE else View.GONE; if(v)b.emptyState.visibility=View.GONE}
    private fun showEmpty(empty:Boolean,q:String,error:String?=null){b.emptyState.visibility=if(empty)View.VISIBLE else View.GONE; b.emptyTitle.text=error?:when{q.isNotBlank()->"Không tìm thấy nội dung phù hợp";tab==1->"Chưa có liên kết kiến thức";tab==2->"Chưa ghim ghi chú nào";else->"Chưa có ghi chú"}; b.emptyBody.text=when{error!=null->"Kiểm tra lại và thử lần nữa.";q.isNotBlank()->"Thử ý gần nghĩa, bớt từ khóa hoặc thêm thẻ mô tả vào ghi chú.";tab==1->"Khi hai ghi chú có chung chủ đề hoặc thẻ, chúng sẽ xuất hiện ở đây.";tab==2->"Nhấn giữ một ghi chú để ghim.";else->"Lưu một ý tưởng, câu nói, ảnh hoặc bản thu âm đầu tiên."}}

    private fun openEditor(note:Note?){ stopPlayback(); stopRecording(false)
        val d=Dialog(this); d.requestWindowFeature(Window.FEATURE_NO_TITLE); val eb=DialogEditorBinding.inflate(layoutInflater); d.setContentView(eb.root)
        d.window?.setBackgroundDrawableResource(android.R.color.transparent); d.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT)
        val s=EditorSession(d,eb,note,note?.attachmentPath,note?.attachmentMime,note?.attachmentPath); editor=s
        eb.editorHeading.text=if(note==null)"Ghi chú mới" else "Chỉnh sửa ghi chú"
        eb.editTitle.setText(note?.title.orEmpty()); eb.editBody.setText(note?.body.orEmpty()); eb.editTags.setText(note?.tags.orEmpty()); eb.editTranscript.setText(note?.transcript.orEmpty())
        eb.deleteButton.visibility=if(note==null)View.GONE else View.VISIBLE; updateAttachmentUi(s)
        if(note!=null) lifecycleScope.launch{ runCatching{repo.related(note)}.getOrNull()?.takeIf{it.isNotEmpty()}?.let{r-> if(editor===s){eb.relatedPreview.visibility=View.VISIBLE;eb.relatedPreview.text="Liên quan: "+r.joinToString(" • "){it.title}}}}
        eb.attachButton.setOnClickListener{pickFile.launch("*/*")}; eb.recordButton.setOnClickListener{ if(recorder!=null)stopRecording(true) else ensureAudioPermission() }
        eb.attachmentLabel.setOnClickListener{ if(s.mime?.startsWith("audio/")==true) togglePlayback(s.path) }
        eb.cancelButton.setOnClickListener{d.dismiss()}; eb.saveButton.setOnClickListener{saveEditor(s)}
        eb.deleteButton.setOnClickListener{ MaterialAlertDialogBuilder(this).setTitle("Xóa ghi chú?").setMessage("Thao tác này không thể hoàn tác.").setNegativeButton("Hủy",null).setPositiveButton("Xóa"){_,_-> lifecycleScope.launch{note?.let{repo.delete(it)};d.dismiss();refresh()}}.show() }
        d.setOnDismissListener{stopRecording(false);stopPlayback(); if(editor===s){ if(!s.saved && s.path!=s.originalPath)repo.discard(s.path);editor=null }}
        d.setOnShowListener{d.window?.setLayout((resources.displayMetrics.widthPixels*.94).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)}; d.show()
        eb.editTitle.requestFocus(); eb.editTitle.postDelayed({(getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(eb.editTitle,InputMethodManager.SHOW_IMPLICIT)},180)
    }

    private fun saveEditor(s:EditorSession){ val title=s.b.editTitle.text?.toString()?.trim().orEmpty(); if(title.isBlank()){s.b.editTitle.error="Cần nhập tiêu đề";return}
        s.b.saveButton.isEnabled=false; lifecycleScope.launch{try{ val old=s.note
            repo.save(Note(id=old?.id?:0,title=title,body=s.b.editBody.text?.toString().orEmpty(),tags=s.b.editTags.text?.toString().orEmpty(),transcript=s.b.editTranscript.text?.toString().orEmpty(),attachmentPath=s.path,attachmentMime=s.mime,pinned=old?.pinned?:false,createdAt=old?.createdAt?:System.currentTimeMillis()))
            s.saved=true; if(s.originalPath!=null&&s.originalPath!=s.path)repo.discard(s.originalPath);s.dialog.dismiss();refresh()
        }catch(e:Throwable){s.b.saveButton.isEnabled=true;message(e.message?:"Không thể lưu ghi chú")}}
    }

    private fun importAttachment(uri:Uri){val s=editor?:return;s.b.attachButton.isEnabled=false;s.b.attachmentLabel.text="Đang nhập tệp…";lifecycleScope.launch{try{
        val oldTemp=if(s.path!=s.originalPath)s.path else null;val result=repo.importAttachment(uri,contentResolver.getType(uri));oldTemp?.let{repo.discard(it)};s.path=result.first;s.mime=result.second;updateAttachmentUi(s)
    }catch(e:Throwable){message(e.message?:"Không thể nhập tệp");updateAttachmentUi(s)}finally{s.b.attachButton.isEnabled=true}}}

    private fun updateAttachmentUi(s:EditorSession){val p=s.path;s.b.attachmentLabel.text=when{p==null->"Chưa có tệp đính kèm";s.mime?.startsWith("audio/")==true->"Âm thanh • chạm để phát / dừng";else->"Ảnh đính kèm • tối đa 25 MB"};s.b.imagePreview.visibility=if(p!=null&&s.mime?.startsWith("image/")==true)View.VISIBLE else View.GONE;if(s.b.imagePreview.visibility==View.VISIBLE)s.b.imagePreview.setImageURI(Uri.fromFile(File(p!!)))}
    private fun ensureAudioPermission(){if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)startRecording() else audioPermission.launch(Manifest.permission.RECORD_AUDIO)}
    private fun startRecording(){val s=editor?:return;try{val file=repo.newRecordingFile();recorder=MediaRecorder().apply{setAudioSource(MediaRecorder.AudioSource.MIC);setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);setAudioEncoder(MediaRecorder.AudioEncoder.AAC);setAudioEncodingBitRate(96_000);setAudioSamplingRate(44_100);setOutputFile(file.absolutePath);setMaxDuration(10*60*1000);setMaxFileSize(25L*1024*1024);setOnInfoListener{_,_,_->stopRecording(true)};prepare();start()};s.pendingRecording=file.absolutePath;s.b.recordButton.text="Dừng thu";s.b.attachmentLabel.text="Đang thu • tối đa 10 phút"
    }catch(e:Throwable){stopRecording(false);message("Không thể bắt đầu thu âm: ${e.message}")}}
    private fun stopRecording(keep:Boolean){val r=recorder?:return;recorder=null;val s=editor;runCatching{r.stop()};runCatching{r.reset()};runCatching{r.release()};val path=s?.pendingRecording;s?.pendingRecording=null;s?.b?.recordButton?.text="Thu âm";if(keep&&path!=null&&File(path).length()>512){if(s.path!=s.originalPath)repo.discard(s.path);s.path=path;s.mime="audio/mp4";updateAttachmentUi(s)}else repo.discard(path)}
    private fun togglePlayback(path:String?){if(player!=null){stopPlayback();message("Đã dừng phát");return};if(path==null)return;try{player=MediaPlayer().apply{setDataSource(path);setOnCompletionListener{stopPlayback()};setOnErrorListener{_,_,_->stopPlayback();true};prepare();start()};message("Đang phát âm thanh") }catch(e:Throwable){stopPlayback();message("Không thể phát âm thanh")}}
    private fun stopPlayback(){player?.let{runCatching{it.stop()};runCatching{it.release()}};player=null}
    private fun togglePin(note:Note){lifecycleScope.launch{repo.pin(note,!note.pinned);message(if(note.pinned)"Đã bỏ ghim" else "Đã ghim");refresh()}}
    private fun message(text:String)=Snackbar.make(b.root,text,Snackbar.LENGTH_SHORT).show()
    override fun onStop(){super.onStop();stopRecording(true);stopPlayback()}
    override fun onDestroy(){loadJob?.cancel();super.onDestroy()}
    private data class EditorSession(val dialog:Dialog,val b:DialogEditorBinding,val note:Note?,var path:String?,var mime:String?,val originalPath:String?,var pendingRecording:String?=null,var saved:Boolean=false)
}
