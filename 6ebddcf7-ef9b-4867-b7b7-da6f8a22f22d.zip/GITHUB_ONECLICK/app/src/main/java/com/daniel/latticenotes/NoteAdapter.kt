package com.daniel.latticenotes

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.daniel.latticenotes.databinding.ItemNoteBinding
import java.text.DateFormat
import java.util.Date

class NoteAdapter(private val onClick:(Note)->Unit, private val onLong:(Note)->Unit) : ListAdapter<Note,NoteAdapter.Holder>(DIFF) {
    class Holder(val b:ItemNoteBinding):RecyclerView.ViewHolder(b.root)
    override fun onCreateViewHolder(p:ViewGroup,v:Int)=Holder(ItemNoteBinding.inflate(LayoutInflater.from(p.context),p,false))
    override fun onBindViewHolder(h:Holder,pos:Int){ val n=getItem(pos); with(h.b){
        noteTitle.text=n.title
        val kind=when{ n.attachmentMime?.startsWith("image/")==true->"Ảnh"; n.attachmentMime?.startsWith("audio/")==true->"Âm thanh"; else->"Văn bản" }
        typeIcon.text=when(kind){"Ảnh"->"▧";"Âm thanh"->"◖";else->"✎"}
        val relation=if(n.relationCount>0) " • ${n.relationCount} liên kết" else ""
        val pin=if(n.pinned) " • Đã ghim" else ""
        meta.text="$kind$relation$pin • ${DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(n.updatedAt))}"
        snippet.text=(n.body.ifBlank{n.transcript}).ifBlank{"Không có nội dung văn bản"}
        tags.text=if(n.tags.isBlank()) "" else n.tags.split(',').map{it.trim()}.filter{it.isNotEmpty()}.joinToString("   "){"#$it"}
        root.setOnClickListener{onClick(n)}; root.setOnLongClickListener{onLong(n);true}
    }}
    companion object { val DIFF=object:DiffUtil.ItemCallback<Note>(){ override fun areItemsTheSame(a:Note,b:Note)=a.id==b.id; override fun areContentsTheSame(a:Note,b:Note)=a==b } }
}
