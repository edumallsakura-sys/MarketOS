package com.daniel.latticenotes

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.io.File
import java.util.UUID
import java.util.concurrent.Executors

class NoteRepository(private val context: Context) {
    private val db = NoteDb(context)
    private val dispatcher: CoroutineDispatcher = Executors.newFixedThreadPool(2) { r -> Thread(r, "lattice-io").apply { isDaemon=true } }.asCoroutineDispatcher()
    suspend fun list(): List<Note> = withContext(dispatcher) { withTimeout(2_000) { db.all() } }
    suspend fun search(query: String): List<Note> = withContext(dispatcher) { withTimeout(2_000) { SearchEngine.search(db.all(), query) } }
    suspend fun links(): List<Note> = withContext(dispatcher) { withTimeout(3_000) { SearchEngine.withRelations(db.all()) } }
    suspend fun related(note: Note): List<Note> = withContext(dispatcher) { withTimeout(2_000) { SearchEngine.relatedTo(note, db.all()) } }
    suspend fun save(note: Note): Long = withContext(dispatcher) { withTimeout(2_000) { db.upsert(note) } }
    suspend fun delete(note: Note) = withContext(dispatcher) {
        withTimeout(2_000) { db.delete(note.id); note.attachmentPath?.let { safeDelete(it) } }
    }
    suspend fun pin(note: Note, value:Boolean) = withContext(dispatcher) { withTimeout(2_000) { db.togglePin(note.id,value) } }
    suspend fun importAttachment(uri: Uri, mime: String?): Pair<String,String> = withContext(dispatcher) {
        withTimeout(30_000) {
            val type = mime ?: context.contentResolver.getType(uri) ?: "application/octet-stream"
            require(type.startsWith("image/") || type.startsWith("audio/")) { "Chỉ hỗ trợ ảnh hoặc âm thanh" }
            val dir=File(context.filesDir,"attachments").apply{mkdirs()}; val ext=if(type.startsWith("image/")) ".img" else ".audio"
            val out=File(dir, UUID.randomUUID().toString()+ext); var total=0L
            try { context.contentResolver.openInputStream(uri)?.use { input -> out.outputStream().buffered().use { output ->
                val buf=ByteArray(32*1024); while(true){ val n=input.read(buf); if(n<0) break; total+=n; require(total<=25L*1024*1024){"Tệp vượt quá giới hạn 25 MB"}; output.write(buf,0,n) }
            }} ?: error("Không thể mở tệp") } catch(t:Throwable){ out.delete(); throw t }
            out.absolutePath to type
        }
    }
    fun newRecordingFile(): File = File(context.filesDir,"attachments").apply{mkdirs()}.let{File(it,"rec_${System.currentTimeMillis()}.m4a")}
    fun discard(path:String?){ path?.let{safeDelete(it)} }
    private fun safeDelete(path:String){ val f=File(path); val root=File(context.filesDir,"attachments"); if(f.canonicalPath.startsWith(root.canonicalPath)) f.delete() }
}
