# Release notes — Android shell 3.15.0

- Packaged the supplied Lingua Mentor 3.15.0 HTML without deleting or rewriting its application logic.
- Added secure local-origin WebView bridge instead of exposing JavascriptInterface to third-party iframes.
- Added Android TTS and stop control.
- Added bounded native HTTP POST bridge and translation bridge.
- Added Android file chooser support.
- Added MediaProjection + AudioPlaybackCapture bridge for system-audio ASR fallback on Android 10+.
- Added finite capture timeout (max 180 s), bounded HTTP response size (32 MiB), bounded executor pool, cleanup on destroy, and no infinite native polling.
- Added GitHub Actions debug APK build for JDK 17 / Gradle 8.9 / Android 35.
