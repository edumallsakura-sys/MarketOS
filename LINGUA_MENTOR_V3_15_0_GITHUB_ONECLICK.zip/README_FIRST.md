# UPLOAD FILE NÀY NGUYÊN ZIP LÊN GITHUB

Gói ngoài chứa `LINGUA_MENTOR_V3_15_0_ANDROID_FULL_SOURCE.zip` để tương thích quy trình bootstrap OneClick cũ: bootstrap tìm ZIP mới nhất → giải nén gói ngoài → giải nén FULL_SOURCE → tìm `settings.gradle` → build `:app:assembleDebug`.

FULL_SOURCE SHA-256: `b87613e3b8c366f2b21f6410ac72ccaaa20deae149561bfe2f318dbee5ec825e`

---

# Lingua Mentor v3.15.0 — GitHub OneClick Android package

This package wraps the supplied Lingua Mentor HTML in a native Android WebView shell and preserves the original HTML byte-for-byte.

- App: Lingua Mentor
- HTML version: 3.15.0
- Package ID: `com.linguamentor.app`
- minSdk: 26
- target/compileSdk: 35
- Java: 17
- Gradle: 8.9 (installed by GitHub Actions)
- Android Gradle Plugin: 8.7.3
- Original HTML SHA-256: `f45dc08de6a683c975ce868bad53fbbbe180910b4e49806cc9bf50db6ed30dfb`

## Native capabilities included

1. Secure same-origin JS bridge using AndroidX WebMessageListener. Third-party YouTube/X frames do not receive the native port.
2. Android TextToSpeech: `ttsSpeakAsync` + `ttsStopAsync`.
3. Native HTTP POST bridge with 15s connect / 120s read timeout and 32 MiB bounded response.
4. Translation bridge using the Google translate endpoint; the HTML still retains its own fallback chain.
5. File picker for SRT/VTT/TXT/media inputs.
6. MediaProjection + AudioPlaybackCapture system-audio bridge on Android 10+, hard-limited to 180 seconds, with foreground notification and cleanup.
7. `adjustResize` keyboard behavior for WebView forms.
8. Explicit WebView teardown and bounded executor threads.

## Build in a normal extracted GitHub repository

Upload/extract the contents so `.github/workflows/build-apk.yml` is visible in the repository, then run **Actions → Build Lingua Mentor APK → Run workflow**. Download artifact `LinguaMentor-v3.15.0-APK`.

## Your preferred raw-ZIP upload flow

If your repository already has the persistent bootstrap workflow from earlier builds, upload this `...GITHUB_ONECLICK.zip` **as-is**. The bootstrap can extract the newest ZIP, detect `settings.gradle`, run Gradle and upload the APK.

For a brand-new repository, GitHub cannot execute a workflow that is hidden inside an unopened ZIP. A ready persistent bootstrap file is included as `PERSISTENT_BOOTSTRAP_build-apk.yml`; copy it once to `.github/workflows/build-apk.yml`, commit it, then future OneClick ZIP files can be uploaded raw.

## Honest limitations

- The supplied input is a single HTML file. It references some optional bundled audio paths and remote/local Whisper backends; no missing audio/model binaries were fabricated.
- Native `fetchTranscriptAsync`, `extractMediaAsync`, and `whisperTranscribeAsync` are intentionally **not** advertised by the shell because this package does not contain a trustworthy native extractor or libwhisper binary. The HTML's own InnerTube/Invidious/local-WASM/backend fallback logic remains available.
- System-audio capture depends on Android/device playback-capture policy. Some protected or non-capturable media may produce silence; the app reports an error rather than faking transcript data.
- The GitHub build itself needs internet access to download Gradle/Android/Maven dependencies.
