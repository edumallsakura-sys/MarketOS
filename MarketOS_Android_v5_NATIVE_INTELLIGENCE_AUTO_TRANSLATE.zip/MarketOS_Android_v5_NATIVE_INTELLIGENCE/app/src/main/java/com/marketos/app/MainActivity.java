package com.marketos.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import org.json.JSONArray;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private WebView webView;
    private final ExecutorService executor = Executors.newFixedThreadPool(5);
    private Translator enViTranslator;
    private SharedPreferences prefs;

    private static class FeedItem {
        String title = "", link = "", pubDate = "", description = "", source = "";
        long epoch = 0L;
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("marketos_secure_config", MODE_PRIVATE);
        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.VIETNAMESE)
                .build();
        enViTranslator = Translation.getClient(options);

        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setUserAgentString(s.getUserAgentString() + " MarketOS/5.0");
        webView.addJavascriptInterface(new NativeBridge(), "MarketNative");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class NativeBridge {
        @JavascriptInterface public void refreshFed() {
            executor.execute(() -> {
                try {
                    List<FeedItem> all = new ArrayList<>();
                    all.addAll(fetchFeed("https://www.federalreserve.gov/feeds/press_monetary.xml", "Monetary Policy"));
                    all.addAll(fetchFeed("https://www.federalreserve.gov/feeds/speeches.xml", "Speech"));
                    all.addAll(fetchFeed("https://www.federalreserve.gov/feeds/testimony.xml", "Testimony"));
                    all.addAll(fetchFeed("https://www.federalreserve.gov/feeds/press_all.xml", "Press Release"));
                    all.addAll(fetchFeed("https://www.federalreserve.gov/feeds/clp.xml", "Liquidity/Balance Sheet"));
                    List<FeedItem> unique = new ArrayList<>();
                    Set<String> seen = new HashSet<>();
                    for (FeedItem item : all) {
                        String key = item.link.isEmpty() ? item.title + item.pubDate : item.link;
                        if (seen.add(key)) unique.add(item);
                    }
                    Collections.sort(unique, (a,b) -> Long.compare(b.epoch, a.epoch));
                    JSONArray arr = new JSONArray();
                    for (int i=0;i<Math.min(unique.size(),140);i++) {
                        FeedItem x=unique.get(i); JSONObject o=new JSONObject();
                        o.put("title",x.title); o.put("link",x.link); o.put("pubDate",x.pubDate);
                        o.put("description",clean(x.description)); o.put("source",x.source); o.put("importance",importance(x));
                        arr.put(o);
                    }
                    JSONObject p=new JSONObject(); p.put("ok",true); p.put("updatedAt",isoNow()); p.put("items",arr);
                    send("onFedPayload",p.toString());
                } catch(Exception e) { sendError("onFedPayload", e); }
            });
        }

        @JavascriptInterface public void fetchFedArticle(String requestId, String url) {
            executor.execute(() -> {
                try {
                    Uri u=Uri.parse(url); String h=u.getHost();
                    if (!"https".equalsIgnoreCase(u.getScheme()) || h==null || !h.endsWith("federalreserve.gov"))
                        throw new IllegalArgumentException("Chỉ cho phép tài liệu chính thức federalreserve.gov");
                    String text = fetchArticleText(url);
                    JSONObject p = new JSONObject();
                    p.put("ok", true); p.put("requestId", requestId); p.put("url", url); p.put("text", text);
                    p.put("analysis", analyzeTone(text)); p.put("updatedAt", isoNow());
                    send("onFedArticlePayload", p.toString());
                } catch (Exception e) { sendReqError("onFedArticlePayload", requestId, e); }
            });
        }

        @JavascriptInterface public void translateToVietnamese(String requestId, String text) {
            executor.execute(() -> {
                try {
                    if (text == null || text.trim().isEmpty()) throw new IllegalArgumentException("Không có văn bản để dịch");
                    DownloadConditions conditions = new DownloadConditions.Builder().build();
                    Tasks.await(enViTranslator.downloadModelIfNeeded(conditions), 90, TimeUnit.SECONDS);
                    String translated = translateChunks(text);
                    JSONObject p = new JSONObject(); p.put("ok", true); p.put("requestId", requestId);
                    p.put("provider", "ML Kit on-device"); p.put("translated", translated);
                    send("onTranslationPayload", p.toString());
                } catch (Exception localError) {
                    try {
                        String endpoint=prefs.getString("ai_endpoint","");
                        String model=prefs.getString("ai_model","");
                        String key=prefs.getString("ai_key","");
                        if(endpoint.isEmpty()||model.isEmpty()||key.isEmpty()) throw localError;
                        String translated=callOpenAiCompatible(endpoint,model,key,text);
                        JSONObject p = new JSONObject(); p.put("ok", true); p.put("requestId", requestId);
                        p.put("provider", "AI API fallback"); p.put("translated", translated);
                        send("onTranslationPayload", p.toString());
                    } catch (Exception fallbackError) {
                        sendReqError("onTranslationPayload", requestId, new IllegalStateException("ML Kit: "+localError.getMessage()+" | AI fallback: "+fallbackError.getMessage()));
                    }
                }
            });
        }

        @JavascriptInterface public void saveAiTranslator(String endpoint, String model, String apiKey) {
            try {
                Uri u=Uri.parse(endpoint==null?"":endpoint.trim());
                if (!"https".equalsIgnoreCase(u.getScheme()) || u.getHost()==null) throw new IllegalArgumentException("Endpoint phải dùng HTTPS");
                prefs.edit().putString("ai_endpoint", endpoint.trim()).putString("ai_model", model==null?"":model.trim())
                        .putString("ai_key", apiKey==null?"":apiKey.trim()).apply();
                JSONObject p=new JSONObject(); p.put("ok",true); p.put("endpoint",endpoint.trim()); p.put("model",model==null?"":model.trim()); p.put("hasKey",apiKey!=null&&!apiKey.trim().isEmpty());
                send("onAiConfigPayload",p.toString());
            } catch(Exception e){ sendError("onAiConfigPayload",e); }
        }

        @JavascriptInterface public void getAiTranslatorConfig() {
            try {
                JSONObject p=new JSONObject(); p.put("ok",true); p.put("endpoint",prefs.getString("ai_endpoint","https://api.groq.com/openai/v1/chat/completions"));
                p.put("model",prefs.getString("ai_model","llama-3.1-8b-instant")); p.put("hasKey",!prefs.getString("ai_key","").isEmpty());
                send("onAiConfigPayload",p.toString());
            }catch(Exception ignored){}
        }

        @JavascriptInterface public void translateWithAi(String requestId, String text) {
            executor.execute(() -> {
                try {
                    String endpoint=prefs.getString("ai_endpoint",""); String model=prefs.getString("ai_model",""); String key=prefs.getString("ai_key","");
                    if(endpoint.isEmpty()||model.isEmpty()||key.isEmpty()) throw new IllegalStateException("Chưa cấu hình API dịch AI");
                    String translated=callOpenAiCompatible(endpoint,model,key,text);
                    JSONObject p=new JSONObject(); p.put("ok",true);p.put("requestId",requestId);p.put("provider","AI API");p.put("translated",translated);
                    send("onTranslationPayload",p.toString());
                }catch(Exception e){sendReqError("onTranslationPayload",requestId,e);}
            });
        }

        @JavascriptInterface public void fetchFredSeries(String id) {
            executor.execute(() -> {
                try { send("onFredSeriesPayload", fetchFred(id).toString()); }
                catch(Exception e) { sendFredError(id,e); }
            });
        }

        @JavascriptInterface public void openExternal(String url) {
            try {
                Uri u=Uri.parse(url); String h=u.getHost();
                if ("https".equalsIgnoreCase(u.getScheme()) && h!=null &&
                    (h.endsWith("federalreserve.gov") || h.endsWith("fred.stlouisfed.org") || h.endsWith("newyorkfed.org"))) {
                    startActivity(new Intent(Intent.ACTION_VIEW,u));
                }
            } catch(Exception ignored) {}
        }
    }

    private String translateChunks(String text) throws Exception {
        String normalized=text.replace("\r","").trim();
        List<String> chunks=new ArrayList<>(); int start=0;
        while(start<normalized.length()){
            int end=Math.min(start+2800,normalized.length());
            if(end<normalized.length()){
                int cut=Math.max(normalized.lastIndexOf(". ",end), normalized.lastIndexOf("\n",end));
                if(cut>start+1200) end=cut+1;
            }
            chunks.add(normalized.substring(start,end).trim()); start=end;
        }
        StringBuilder out=new StringBuilder();
        for(String c:chunks){ if(c.isEmpty())continue; String t=Tasks.await(enViTranslator.translate(c),45,TimeUnit.SECONDS); if(out.length()>0)out.append("\n\n");out.append(t); }
        return out.toString();
    }

    private String callOpenAiCompatible(String endpoint,String model,String key,String text) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(endpoint).openConnection(); c.setRequestMethod("POST"); c.setDoOutput(true);
        c.setConnectTimeout(15000); c.setReadTimeout(60000); c.setRequestProperty("Authorization","Bearer "+key); c.setRequestProperty("Content-Type","application/json"); c.setRequestProperty("Accept","application/json");
        JSONObject body=new JSONObject(); body.put("model",model); body.put("temperature",0.1);
        JSONArray msgs=new JSONArray(); msgs.put(new JSONObject().put("role","system").put("content","Translate the supplied Federal Reserve or financial-market text into clear Vietnamese. Preserve numbers, dates, policy terms, uncertainty and speaker intent. Do not add investment advice or facts not present in the source."));
        msgs.put(new JSONObject().put("role","user").put("content",text.length()>18000?text.substring(0,18000):text)); body.put("messages",msgs);
        byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8); c.setFixedLengthStreamingMode(bytes.length); try(OutputStream os=c.getOutputStream()){os.write(bytes);} int code=c.getResponseCode();
        BufferedReader br=new BufferedReader(new InputStreamReader(code>=200&&code<300?c.getInputStream():c.getErrorStream(),StandardCharsets.UTF_8)); StringBuilder sb=new StringBuilder();String line;while((line=br.readLine())!=null)sb.append(line);br.close();c.disconnect();
        if(code<200||code>=300)throw new IllegalStateException("AI API HTTP "+code+": "+sb.substring(0,Math.min(400,sb.length())));
        JSONObject r=new JSONObject(sb.toString()); return r.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim();
    }

    private String fetchArticleText(String urlString) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(urlString).openConnection(); c.setConnectTimeout(12000);c.setReadTimeout(20000);c.setRequestProperty("User-Agent","MarketOS/5.0 Android");c.setRequestProperty("Accept","text/html,application/xhtml+xml");
        int code=c.getResponseCode();if(code<200||code>=300)throw new IllegalStateException("Fed article HTTP "+code);
        BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream(),StandardCharsets.UTF_8));StringBuilder html=new StringBuilder();String line;while((line=br.readLine())!=null&&html.length()<1200000)html.append(line).append('\n');br.close();c.disconnect();
        String raw=html.toString(); String lower=raw.toLowerCase(Locale.US); int ms=lower.indexOf("<main"); if(ms>=0){int gt=raw.indexOf('>',ms);int me=lower.indexOf("</main>",gt);if(gt>=0&&me>gt)raw=raw.substring(gt+1,me);} 
        raw=raw.replaceAll("(?is)<script[^>]*>.*?</script>"," ").replaceAll("(?is)<style[^>]*>.*?</style>"," ").replaceAll("(?is)<nav[^>]*>.*?</nav>"," ").replaceAll("(?is)<header[^>]*>.*?</header>"," ").replaceAll("(?is)<footer[^>]*>.*?</footer>"," ");
        raw=raw.replaceAll("(?i)<br\\s*/?>","\n").replaceAll("(?i)</p\\s*>","\n\n").replaceAll("(?i)</h[1-6]\\s*>","\n\n").replaceAll("(?i)</li\\s*>","\n");
        String txt=Html.fromHtml(raw,Html.FROM_HTML_MODE_LEGACY).toString().replace('\u00a0',' ').replaceAll("[ \\t]+"," ").replaceAll("\\n{3,}","\n\n").trim();
        txt=txt.replaceAll("(?is)^.*?(For release at|Speech|Testimony|Press Release)","$1");
        if(txt.length()>30000)txt=txt.substring(0,30000); if(txt.length()<120)throw new IllegalStateException("Không trích được nội dung tài liệu"); return txt;
    }

    private JSONObject analyzeTone(String text) throws Exception {
        String t=text.toLowerCase(Locale.US); String[] hawk={"inflation remains elevated","inflation is still elevated","upside risks to inflation","restrictive","higher for longer","not appropriate to reduce","not yet confident","tight labor market","further tightening"};
        String[] dove={"disinflation","downside risks to employment","labor market has cooled","easing","reduce the target range","rate cuts","less restrictive","inflation has eased","risks are roughly in balance"}; int hs=0,ds=0;JSONArray hm=new JSONArray(),dm=new JSONArray();
        for(String k:hawk)if(t.contains(k)){hs++;hm.put(k);}for(String k:dove)if(t.contains(k)){ds++;dm.put(k);} JSONObject o=new JSONObject();o.put("hawk",hs);o.put("dove",ds);o.put("label",hs>ds?"HAWKISH":ds>hs?"DOVISH":"NEUTRAL/MIXED");o.put("hawkMatches",hm);o.put("doveMatches",dm);return o;
    }

    private JSONObject fetchFred(String rawId) throws Exception {
        String id=(rawId==null?"":rawId.trim().toUpperCase(Locale.US)); if(!id.matches("[A-Z0-9_.-]{1,64}")) throw new IllegalArgumentException("FRED series ID không hợp lệ");
        java.util.Calendar cal=java.util.Calendar.getInstance();cal.add(java.util.Calendar.YEAR,-2);String cosd=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(cal.getTime());
        String url="https://fred.stlouisfed.org/graph/fredgraph.csv?id="+URLEncoder.encode(id,"UTF-8")+"&cosd="+cosd;HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(12000);c.setReadTimeout(18000);c.setRequestProperty("User-Agent","MarketOS/5.0 Android");int code=c.getResponseCode();if(code<200||code>=300)throw new IllegalStateException("FRED HTTP "+code);
        BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"));String line=br.readLine();if(line==null||!line.toUpperCase(Locale.US).contains(id))throw new IllegalStateException("Không tìm thấy series "+id);List<String> dates=new ArrayList<>();List<Double> vals=new ArrayList<>();
        while((line=br.readLine())!=null){String[] a=line.split(",",-1);if(a.length<2)continue;String v=a[1].replace("\"","").trim();if(v.isEmpty()||".".equals(v)||"NA".equalsIgnoreCase(v))continue;try{dates.add(a[0].replace("\"","").trim());vals.add(Double.parseDouble(v));}catch(Exception ignored){}}br.close();c.disconnect();if(vals.isEmpty())throw new IllegalStateException("Series chưa có dữ liệu khả dụng");
        int n=vals.size();double value=vals.get(n-1);Double previous=n>1?vals.get(n-2):null;JSONObject p=new JSONObject();p.put("ok",true);p.put("id",id);p.put("date",dates.get(n-1));p.put("value",value);if(previous!=null){double delta=value-previous;p.put("previous",previous);p.put("delta",delta);if(previous!=0)p.put("pct",delta/Math.abs(previous)*100.0);}JSONArray hist=new JSONArray();int start=Math.max(0,n-60);for(int i=start;i<n;i++){JSONObject x=new JSONObject();x.put("date",dates.get(i));x.put("value",vals.get(i));hist.put(x);}p.put("history",hist);p.put("updatedAt",isoNow());return p;
    }

    private List<FeedItem> fetchFeed(String urlString,String source) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(urlString).openConnection();c.setConnectTimeout(12000);c.setReadTimeout(15000);c.setRequestProperty("User-Agent","MarketOS/5.0 Android");c.setRequestProperty("Accept","application/rss+xml, application/xml, text/xml, */*");int code=c.getResponseCode();if(code<200||code>=300)throw new IllegalStateException("Fed feed HTTP "+code);
        XmlPullParserFactory f=XmlPullParserFactory.newInstance();f.setNamespaceAware(false);XmlPullParser p=f.newPullParser();p.setInput(new BufferedInputStream(c.getInputStream()),"UTF-8");List<FeedItem> out=new ArrayList<>();FeedItem cur=null;String tag="";int ev=p.getEventType();while(ev!=XmlPullParser.END_DOCUMENT){if(ev==XmlPullParser.START_TAG){tag=p.getName().toLowerCase(Locale.US);if("item".equals(tag))cur=new FeedItem();}else if(ev==XmlPullParser.TEXT&&cur!=null){String tx=p.getText();if(tx!=null){if("title".equals(tag))cur.title+=tx;else if("link".equals(tag))cur.link+=tx;else if("pubdate".equals(tag))cur.pubDate+=tx;else if("description".equals(tag))cur.description+=tx;}}else if(ev==XmlPullParser.END_TAG){String end=p.getName().toLowerCase(Locale.US);if("item".equals(end)&&cur!=null){cur.source=source;cur.title=clean(cur.title);cur.link=cur.link.trim();cur.pubDate=cur.pubDate.trim();cur.epoch=parseRssDate(cur.pubDate);out.add(cur);cur=null;}tag="";}ev=p.next();}c.disconnect();return out;
    }

    private void send(String fn,String json){final String q=JSONObject.quote(json);runOnUiThread(()->webView.evaluateJavascript("window."+fn+"(JSON.parse("+q+"));",null));}
    private void sendError(String fn,Exception e){try{JSONObject p=new JSONObject();p.put("ok",false);p.put("error",e.getClass().getSimpleName()+": "+e.getMessage());send(fn,p.toString());}catch(Exception ignored){}}
    private void sendReqError(String fn,String requestId,Exception e){try{JSONObject p=new JSONObject();p.put("ok",false);p.put("requestId",requestId);p.put("error",e.getClass().getSimpleName()+": "+e.getMessage());send(fn,p.toString());}catch(Exception ignored){}}
    private void sendFredError(String id,Exception e){try{JSONObject p=new JSONObject();p.put("ok",false);p.put("id",id);p.put("error",e.getMessage());send("onFredSeriesPayload",p.toString());}catch(Exception ignored){}}
    private static String clean(String s){if(s==null)return"";return s.replaceAll("<[^>]+>"," ").replace("&nbsp;"," ").replace("&amp;","&").replace("&quot;","\"").replace("&#39;","'").replaceAll("\\s+"," ").trim();}
    private static long parseRssDate(String value){if(value==null)return 0L;String[] ps={"EEE, dd MMM yyyy HH:mm:ss z","EEE, dd MMM yyyy HH:mm z","MM/dd/yyyy"};for(String x:ps)try{Date d=new SimpleDateFormat(x,Locale.US).parse(value.trim());if(d!=null)return d.getTime();}catch(Exception ignored){}return 0L;}
    private static String importance(FeedItem x){String t=(x.title+" "+x.source).toLowerCase(Locale.US);if(t.contains("fomc")||t.contains("minutes")||t.contains("monetary policy report")||t.contains("projection")||t.contains("federal funds")||t.contains("beige book"))return"CRITICAL";if(t.contains("chair")||t.contains("economic outlook")||t.contains("testimony")||t.contains("balance sheet")||t.contains("liquidity"))return"HIGH";return"NORMAL";}
    private static String isoNow(){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX",Locale.US);f.setTimeZone(TimeZone.getDefault());return f.format(new Date());}
    @Override protected void onDestroy(){executor.shutdownNow();if(enViTranslator!=null)enViTranslator.close();if(webView!=null)webView.destroy();super.onDestroy();}
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
