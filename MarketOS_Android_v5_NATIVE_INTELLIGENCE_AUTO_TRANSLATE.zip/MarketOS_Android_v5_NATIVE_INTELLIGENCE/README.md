# Market OS Android v5 — Native Intelligence

## Nâng cấp chính
- Fed Intelligence đọc nội dung bài chính thức ngay trong app thay vì chỉ mở link.
- Tự trích nội dung từ federalreserve.gov và hiển thị nguyên bản.
- Tự dịch English -> Vietnamese bằng Google ML Kit on-device, không cần API key.
- Lần đầu ML Kit có thể tải model ngôn ngữ; sau khi có model, dịch chạy trên thiết bị.
- Có fallback API AI OpenAI-compatible nếu người dùng tự nhập endpoint/model/API key.
- Có preset mặc định cho Groq endpoint, nhưng KHÔNG nhúng API key.
- API key chỉ lưu cục bộ trong SharedPreferences của app và không được trả ngược lên giao diện.
- Fed article reader có heuristic Hawkish / Dovish / Neutral-Mixed. Đây chỉ là bộ lọc từ khóa để hỗ trợ đọc, không phải tín hiệu đầu tư.
- Watchlist FRED, Crypto và icon ứng dụng từ bản v4 được giữ nguyên.

## Dịch tự động
Mặc định: ML Kit `com.google.mlkit:translate:17.0.3`.
Min SDK của app là 24.
Ngôn ngữ mặc định: English -> Vietnamese.

Nếu ML Kit lỗi và đã cấu hình AI API, app tự thử fallback qua endpoint OpenAI-compatible.
Có thể dùng Groq/OpenRouter/endpoint riêng miễn là API tương thích `chat/completions`.

## Build trên GitHub
Đặt `build-apk.yml` trong `.github/workflows/` rồi chạy GitHub Actions.
Workflow hỗ trợ project đã giải nén hoặc Android project nằm trong ZIP.

## Lưu ý
- Không có API key nào được hard-code trong source.
- Chất lượng dịch thuật tài chính vẫn nên được kiểm tra với nguyên bản khi dùng cho quyết định đầu tư.
- Fed tone score là heuristic, không phải mô hình dự báo.
