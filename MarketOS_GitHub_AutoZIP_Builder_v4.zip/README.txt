MARKET OS - GITHUB AUTO ZIP APK BUILDER

Cach dung don gian:
1. Tao repository GitHub moi.
2. Tai TOAN BO noi dung cua file ZIP nay len root repository.
3. Ban co the thay file trong thu muc projects/ bang BAT KY project Android .zip nao.
   - Co the dat ZIP o thu muc bat ky trong repository.
   - Workflow quet tat ca file .zip.
   - Tu giai nen ZIP, ke ca ZIP long ben trong ZIP toi da 4 tang.
   - Tu tim project Android Gradle qua settings.gradle / settings.gradle.kts.
   - Neu project co gradlew thi uu tien Gradle Wrapper cua project.
   - Neu khong co gradlew thi dung Gradle 8.11.1 du phong.
   - Tu build debug APK va gom tat ca APK vao Artifact Android-APKs.
4. Vao GitHub > Actions > Auto Build Android APK from ZIP > Run workflow.
5. Build xanh > mo run > Artifacts > Android-APKs > tai APK ve.

Luu y:
- ZIP phai chua project Android co settings.gradle(.kts) va module Android.
- Neu project can secret/API key/signing key, can khai bao rieng trong GitHub Secrets.
- Workflow build DEBUG APK de de dung. Release APK can keystore va signing config rieng.
- Khong nen dat APK/ZIP khong tin cay vao repo vi GitHub Actions se chay ma build cua project.

File quan trong:
.github/workflows/build-apk.yml

Thu muc projects/ hien da kem MarketOS Android v3 de ban co the upload va build ngay.
